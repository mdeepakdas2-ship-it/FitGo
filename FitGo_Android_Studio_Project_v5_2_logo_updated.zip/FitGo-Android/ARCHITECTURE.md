# FitGo – Clean Architecture & Modular Package Structure

```text
app/src/main/java/com/fitgo/
├── FitGoApplication.kt
├── MainActivity.kt
├── core/
│   ├── design/        (Color.kt, Theme.kt, Components.kt)
│   ├── di/            (AppModule.kt)
│   ├── navigation/    (FitGoNavigation.kt)
│   ├── security/      (CryptoManager.kt, BiometricLockHelper.kt)
│   └── utils/         (FitnessEngines.kt: UnitConverter, PrCalculator, ProgressiveOverloadEngine, PlateCalculator, StreakCalculator, RestTimerState)
├── data/
│   ├── backup/        (BackupAndCsvManager.kt)
│   ├── database/
│   │   ├── FitGoDatabase.kt
│   │   ├── ExerciseSeedData.kt
│   │   ├── dao/       (FitGoDao.kt)
│   │   └── entities/  (Entities.kt)
│   └── repositories/  (FitGoRepository.kt, UserPreferencesRepository.kt)
├── domain/
│   ├── models/        (DomainModels.kt)
│   └── usecases/      (WorkoutUseCases.kt)
└── features/
    ├── FitGoAppRoot.kt
    ├── FitGoMainViewModel.kt
    ├── analytics/     (AnalyticsScreen.kt)
    ├── billing/       (PlayBillingManager.kt)
    ├── history/       (HistoryScreen.kt)
    ├── home/          (HomeScreen.kt)
    ├── notifications/ (RestTimerNotifier.kt)
    ├── settings/      (SettingsScreen.kt)
    └── workout/       (WorkoutScreen.kt)
```
