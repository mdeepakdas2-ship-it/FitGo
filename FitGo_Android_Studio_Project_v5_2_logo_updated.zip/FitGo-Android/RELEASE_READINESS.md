# FitGo 5.1.0 — Release Readiness Notes

## Changes in this repair pass

- Replaced the placeholder Routine Builder with a usable local routine workflow: name, notes, exercise selection, save, one-tap start, and delete for user-created routines.
- Added Body Progress logging for weight, waist, chest, hips, arms, and thighs, with dated history and delete confirmation.
- Added encrypted backup creation and restore through Android's Storage Access Framework. Backup password must be at least 8 characters. Restore validates the encrypted payload/checksum and replaces the local database transactionally; a pre-restore encrypted safety snapshot is also stored in FitGo's private app storage.
- Added workout-history CSV export.
- Added a visible lifetime purchase action and restore action.
- Added client-side RSA signature verification of Google Play purchase payloads before acknowledging and caching entitlement. A locally generated hash alone is no longer treated as proof of purchase.
- Removed Room's destructive migration fallback so an app upgrade cannot silently erase workout data.

## Required developer setup before a real Play purchase test

1. Create the one-time in-app product with ID `fitgo_pro_lifetime` in Play Console.
2. Copy the **Base64-encoded licensing public key** from Play Console.
3. Add this to the developer machine's `~/.gradle/gradle.properties` (do not commit it into the repository):

   `FITGO_PLAY_PUBLIC_KEY=YOUR_BASE64_PLAY_LICENSING_PUBLIC_KEY`

4. Build and test purchase/restore with a Play internal-testing track and a licensed tester account.
5. A backend purchase-token verification service is still the stronger production architecture. The current implementation verifies the signed purchase payload locally; it does not contact Google Play Developer API and therefore cannot independently query server-side revocation/refund state while offline.

## Release blockers that still require a real Android build environment

- The supplied ZIP did not contain the Gradle wrapper JAR/scripts, and this repair environment has no Android SDK or Gradle installation. Therefore no APK/AAB could be compiled here and no Android instrumentation tests could be executed.
- Room schema history/migration files were absent in the supplied project. Destructive migration was removed to protect user data, but an explicit migration chain must be added and tested before shipping an upgrade to users who may already have a database at an older schema version.
- Test the app on physical Android devices: clean install, workout autosave/recovery, routine start, timer notifications, CSV export, encrypted backup/restore (correct and incorrect password), billing pending/purchased/cancelled/restore, process death, and app upgrade.
- Configure the final app signing key, Play Console Data safety, privacy policy, store listing, screenshots, and target API review before production rollout.

## Honest status

This is a repaired development project, **not a verified production release**. Do not publish until the release blockers above are closed and a signed AAB passes Play Console pre-launch testing.
