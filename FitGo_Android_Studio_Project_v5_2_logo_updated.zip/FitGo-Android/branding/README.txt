FitGo official launcher icon assets
- fitgo-app-icon-master.png: 1024x1024 master artwork
- fitgo-app-icon-512.png: 512x512 store/listing icon
- Android launcher density PNGs: app/src/main/res/mipmap-*
- Adaptive icon XML: app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
- Adaptive foreground: app/src/main/res/drawable-nodpi/fitgo_launcher_foreground.png
The AndroidManifest.xml now references @mipmap/ic_launcher.
