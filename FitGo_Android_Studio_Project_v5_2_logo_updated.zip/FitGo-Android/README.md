# FitGo – Offline Workout Companion (5.1.0)

**Tagline:** *Open. Lift. Log. Offline.*

FitGo is a 100% local-first, privacy-focused native Android workout companion engineered with **Kotlin 2.0**, **Jetpack Compose (Material 3)**, **MVVM + Clean Architecture**, **Room SQLite Database**, **DataStore Preferences**, **Hilt DI**, **AES-256-GCM + PBKDF2-HMAC-SHA256 Encrypted Backups**, and **Google Play Billing v7**.

## Main app capabilities
1. **100% Local-First & Zero Telemetry:** No mandatory login, no cloud backend, no analytics SDKs, and no `android.permission.INTERNET` required for core workout functionality.
2. **Complete 4-Mode Theme System (`com.fitgo.core.design`):**
   - **Day Mode**, **Night Mode**, **System Default**, and **Automatic Day & Night Mode** (configurable day/night start times, default 06:00 AM / 06:00 PM, evaluated offline against device timezone).
   - **8 Accent Palettes:** FitGo Violet (`#7654E8`), Ocean Blue (`#1976D2`), Emerald Green (`#159B72`), Royal Purple (`#7045BD`), Sunset Orange (`#E87935`), Rose Pink (`#D94F91`), Crimson Red (`#D94343`), and Teal (`#008F95`), plus custom HEX color validation and WCAG contrast calculation.
3. **Workout Tracking Engine (`com.fitgo.features.workout`):**
   - Supports Normal (`N`), Warm-up (`W`), Drop (`D`), Failure (`F`), and Rest-Pause (`RP`) sets.
   - Automatic previous session performance display & 1-tap auto-fill.
   - Transactional SQLite autosave after every set change and automatic unfinished session recovery on app launch.
   - Undoable set deletion, two-exercise superset pairing/unpairing, and post-workout summary with Epley 1RM PR detection.
4. **Progress & Barbell Tools (`com.fitgo.core.utils`):**
   - Epley 1RM formula (`Weight × (1 + Reps / 30)`) restricted to valid strength exercises (1–15 reps) and explicitly labeled as an estimate.
   - Deterministic Progressive Overload engine (`INCREASE_WEIGHT`, `ADD_REPS`, `MAINTAIN_LOAD`, `FOCUS_CONSISTENCY`).
   - Symmetric Barbell Plate Calculator (`kg` and `lbs`). Body Progress logging is available with Lifetime Pro.
5. **Security, Backup & Localization (`com.fitgo.core.security`, `com.fitgo.data.backup`):**
   - Authenticated `AES/GCM/NoPadding` encryption with 256-bit key derived via `PBKDF2WithHmacSHA256` (210,000 iterations), 16-byte random salt, 12-byte random nonce, SHA-256 payload checksum, and pre-restore safety snapshot.
   - Encrypted backup/restore and workout-history CSV export. Personal-record and body-measurement CSV export methods remain available in the data layer but are not currently exposed as user actions.
   - English and Hindi resources and metric/imperial unit conversion (`kg`/`lbs`, `km`/`mi`, `cm`/`in`). Some newly added screens still need full Hindi localization.

## 5.1.0 repair notes

See [RELEASE_READINESS.md](RELEASE_READINESS.md) for the exact changes, Google Play licensing-key setup, and remaining release blockers. This project must be built and tested in Android Studio before distribution; no APK is included in this source archive.

**Release status:** Development source only. See [RELEASE_READINESS.md](RELEASE_READINESS.md) and [IMPLEMENTATION_REPORT.md](IMPLEMENTATION_REPORT.md). Build, migration, Play Billing, and device QA have not yet been verified.
