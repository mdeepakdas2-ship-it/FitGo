package com.fitgo

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

class FitGoComposeUiTest {
    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun bottomNavigation_allFivePrimaryTabsRenderAndNavigate() {
        composeTestRule.onNodeWithText("Home").assertIsDisplayed()
        composeTestRule.onNodeWithText("Workout").performClick()
        composeTestRule.onNodeWithText("Exercise Library", substring = true).assertIsDisplayed()
        composeTestRule.onNodeWithText("History").performClick()
        composeTestRule.onNodeWithText("Workout History & Calendar").assertIsDisplayed()
        composeTestRule.onNodeWithText("Analytics").performClick()
        composeTestRule.onNodeWithText("Analytics, PR Engine & Tools").assertIsDisplayed()
        composeTestRule.onNodeWithText("Settings").performClick()
        composeTestRule.onNodeWithText("Settings & Appearance").assertIsDisplayed()
    }
}
