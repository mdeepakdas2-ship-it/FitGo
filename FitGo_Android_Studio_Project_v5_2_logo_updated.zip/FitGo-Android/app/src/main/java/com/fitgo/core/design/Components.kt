package com.fitgo.core.design

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun FitGoCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val colors = LocalFitGoColors.current
    val shape = RoundedCornerShape(18.dp)
    if (onClick != null) {
        Card(
            onClick = onClick,
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = colors.surface, contentColor = colors.onSurface),
            border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.45f)),
            elevation = CardDefaults.cardElevation(defaultElevation = if (colors.isDark) 0.dp else 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) { content() }
        }
    } else {
        Card(
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = colors.surface, contentColor = colors.onSurface),
            border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.45f)),
            elevation = CardDefaults.cardElevation(defaultElevation = if (colors.isDark) 0.dp else 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) { content() }
        }
    }
}

@Composable
fun AccessibleStatusBadge(
    label: String,
    isSuccess: Boolean = false,
    isWarning: Boolean = false
) {
    val colors = LocalFitGoColors.current
    val tint = when {
        isSuccess -> colors.success
        isWarning -> colors.warning
        else -> colors.primary
    }
    val icon = when {
        isSuccess -> Icons.Default.CheckCircle
        isWarning -> Icons.Default.Warning
        else -> Icons.Default.Info
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = tint.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, style = MaterialTheme.typography.labelLarge, color = tint)
        }
    }
}

@Composable
fun FitGoBarChart(
    dataPoints: List<Pair<String, Double>>,
    accessibilityTitle: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalFitGoColors.current
    val maxVal = (dataPoints.maxOfOrNull { it.second } ?: 1.0).coerceAtLeast(1.0)
    val summaryDesc = "$accessibilityTitle: " + dataPoints.joinToString(", ") { "${it.first} ${it.second.toInt()}" }

    Column(modifier = modifier.fillMaxWidth().semantics { contentDescription = summaryDesc }) {
        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
            val count = dataPoints.size.coerceAtLeast(1)
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.52f).coerceAtLeast(12f)
            for (step in 1..3) {
                val y = size.height * (1f - step / 3f)
                drawLine(colors.outline.copy(alpha = 0.3f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
            }
            dataPoints.forEachIndexed { idx, (_, value) ->
                val ratio = (value / maxVal).toFloat().coerceIn(0.04f, 1f)
                val barHeight = size.height * ratio
                val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                val top = size.height - barHeight
                drawRoundRect(
                    color = if (value > 0.0) colors.primary else colors.surfaceVariant,
                    topLeft = Offset(left, top),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(10f, 10f)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            dataPoints.forEach { (label, _) ->
                Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = colors.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun FitGoLineChart(
    points: List<Pair<String, Double>>,
    accessibilityTitle: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalFitGoColors.current
    if (points.isEmpty()) return
    val minVal = points.minOf { it.second }
    val maxVal = (points.maxOf { it.second }).coerceAtLeast(minVal + 1.0)
    val summaryDesc = "$accessibilityTitle: " + points.joinToString(", ") { "${it.first}: ${"%.1f".format(it.second)}" }

    Column(modifier = modifier.fillMaxWidth().semantics { contentDescription = summaryDesc }) {
        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
            val stepX = if (points.size > 1) size.width / (points.size - 1) else size.width
            val path = Path()
            points.forEachIndexed { index, (_, value) ->
                val normY = ((value - minVal) / (maxVal - minVal)).toFloat().coerceIn(0f, 1f)
                val x = index * stepX
                val y = size.height - (normY * (size.height * 0.8f) + size.height * 0.1f)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                drawCircle(color = colors.primary, radius = 5.dp.toPx(), center = Offset(x, y))
            }
            if (points.size > 1) {
                drawPath(path = path, color = colors.primary, style = Stroke(width = 3.dp.toPx()))
            }
        }
    }
}
