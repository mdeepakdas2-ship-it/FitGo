package com.fitgo.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Production cryptographic engine for FitGo manual backups and local integrity protection.
 * Uses authenticated AES-256-GCM with PBKDF2WithHmacSHA256 (210,000 iterations),
 * 16-byte random salt, and 12-byte random nonce (IV).
 * Never stores backup passwords in plain text.
 */
object CryptoManager {
    private const val MAGIC_HEADER = "FGK5" // FitGo Backup Format v5
    private const val SALT_LENGTH_BYTES = 16
    private const val NONCE_LENGTH_BYTES = 12
    private const val GCM_TAG_BITS = 128
    private const val PBKDF2_ITERATIONS = 210_000
    private const val KEY_LENGTH_BITS = 256
    private const val KEYSTORE_ALIAS = "FitGoLocalIntegrityKey"

    private val secureRandom = SecureRandom()

    fun encryptBackupPayload(plainJson: String, password: CharArray): ByteArray {
        require(password.isNotEmpty()) { "Backup password must not be empty." }
        val salt = ByteArray(SALT_LENGTH_BYTES).also { secureRandom.nextBytes(it) }
        val nonce = ByteArray(NONCE_LENGTH_BYTES).also { secureRandom.nextBytes(it) }

        val secretKey = deriveAesKeyFromPassword(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(GCM_TAG_BITS, nonce)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)

        val headerBytes = MAGIC_HEADER.toByteArray(StandardCharsets.US_ASCII)
        cipher.updateAAD(headerBytes)
        val cipherText = cipher.doFinal(plainJson.toByteArray(StandardCharsets.UTF_8))

        val buffer = ByteBuffer.allocate(headerBytes.size + SALT_LENGTH_BYTES + NONCE_LENGTH_BYTES + cipherText.size)
        buffer.put(headerBytes)
        buffer.put(salt)
        buffer.put(nonce)
        buffer.put(cipherText)
        return buffer.array()
    }

    fun decryptBackupPayload(encryptedBytes: ByteArray, password: CharArray): String {
        require(password.isNotEmpty()) { "Backup password must not be empty." }
        val headerBytes = MAGIC_HEADER.toByteArray(StandardCharsets.US_ASCII)
        val minSize = headerBytes.size + SALT_LENGTH_BYTES + NONCE_LENGTH_BYTES + (GCM_TAG_BITS / 8)
        require(encryptedBytes.size >= minSize) { "Invalid or truncated FitGo backup file." }

        val buffer = ByteBuffer.wrap(encryptedBytes)
        val actualHeader = ByteArray(headerBytes.size)
        buffer.get(actualHeader)
        require(actualHeader.contentEquals(headerBytes)) { "Unrecognized backup format header." }

        val salt = ByteArray(SALT_LENGTH_BYTES)
        buffer.get(salt)

        val nonce = ByteArray(NONCE_LENGTH_BYTES)
        buffer.get(nonce)

        val cipherText = ByteArray(buffer.remaining())
        buffer.get(cipherText)

        val secretKey = deriveAesKeyFromPassword(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(GCM_TAG_BITS, nonce)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
        cipher.updateAAD(headerBytes)

        val decryptedBytes = cipher.doFinal(cipherText)
        return String(decryptedBytes, StandardCharsets.UTF_8)
    }

    private fun deriveAesKeyFromPassword(password: CharArray, salt: ByteArray): SecretKey {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keySpec = PBEKeySpec(password, salt, PBKDF2_ITERATIONS, KEY_LENGTH_BITS)
        return try {
            val rawKey = factory.generateSecret(keySpec).encoded
            SecretKeySpec(rawKey, "AES")
        } finally {
            keySpec.clearPassword()
        }
    }

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun getOrCreateHardwareBackedSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getEntry(KEYSTORE_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
