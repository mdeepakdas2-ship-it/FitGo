package com.fitgo.core.design

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.time.LocalTime
import java.time.ZoneId

enum class ThemeMode {
    DAY,
    NIGHT,
    SYSTEM,
    AUTO_SCHEDULE
}

@Immutable
data class FitGoSemanticColors(
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val onSecondary: Color,
    val background: Color,
    val onBackground: Color,
    val surface: Color,
    val onSurface: Color,
    val surfaceVariant: Color,
    val onSurfaceVariant: Color,
    val outline: Color,
    val error: Color,
    val success: Color,
    val warning: Color,
    val isDark: Boolean
)

val LocalFitGoColors = staticCompositionLocalOf {
    FitGoSemanticColors(
        primary = AccentPalette.FITGO_VIOLET.primaryColor,
        onPrimary = Color.White,
        secondary = AccentPalette.FITGO_VIOLET.secondaryColor,
        onSecondary = Color.White,
        background = FitGoDesignTokens.DayBackground,
        onBackground = FitGoDesignTokens.DayOnBackground,
        surface = FitGoDesignTokens.DaySurface,
        onSurface = FitGoDesignTokens.DayOnSurface,
        surfaceVariant = FitGoDesignTokens.DaySurfaceVariant,
        onSurfaceVariant = FitGoDesignTokens.DayOnSurfaceVariant,
        outline = FitGoDesignTokens.DayOutline,
        error = FitGoDesignTokens.ErrorDay,
        success = FitGoDesignTokens.SuccessDay,
        warning = FitGoDesignTokens.WarningDay,
        isDark = false
    )
}

object AutoThemeEvaluator {
    /**
     * Evaluates whether Night Mode should be active given the current device local time,
     * dayStartMinutes (default 360 = 06:00 AM), and nightStartMinutes (default 1080 = 06:00 PM).
     * Works completely offline and handles wrapped schedules (e.g., Day at 07:00, Night at 19:00
     * or inverted schedules).
     */
    fun isNightTimeNow(
        currentTime: LocalTime = LocalTime.now(ZoneId.systemDefault()),
        dayStartMinutes: Int = 6 * 60,
        nightStartMinutes: Int = 18 * 60
    ): Boolean {
        val currentMinutes = currentTime.hour * 60 + currentTime.minute
        return if (dayStartMinutes < nightStartMinutes) {
            // Standard schedule: Day is [dayStart, nightStart), Night is outside that window
            currentMinutes < dayStartMinutes || currentMinutes >= nightStartMinutes
        } else if (dayStartMinutes > nightStartMinutes) {
            // Wrapped schedule: Night is [nightStart, dayStart)
            currentMinutes in nightStartMinutes until dayStartMinutes
        } else {
            false
        }
    }
}

val FitGoTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp
    )
)

@Composable
fun FitGoTheme(
    themeMode: ThemeMode,
    accentPalette: AccentPalette,
    customHexColor: String?,
    dayStartMinutes: Int = 6 * 60,
    nightStartMinutes: Int = 18 * 60,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val systemDark = isSystemInDarkTheme()

    var timeEvaluationTrigger by remember { mutableStateOf(0L) }

    // Re-evaluate automatic schedule when app resumes or when timezone/time changes (no background service required)
    DisposableEffect(lifecycleOwner, context, themeMode) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                timeEvaluationTrigger = System.currentTimeMillis()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                timeEvaluationTrigger = System.currentTimeMillis()
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        context.registerReceiver(receiver, filter)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    val isDarkTheme = remember(themeMode, systemDark, dayStartMinutes, nightStartMinutes, timeEvaluationTrigger) {
        when (themeMode) {
            ThemeMode.DAY -> false
            ThemeMode.NIGHT -> true
            ThemeMode.SYSTEM -> systemDark
            ThemeMode.AUTO_SCHEDULE -> AutoThemeEvaluator.isNightTimeNow(
                currentTime = LocalTime.now(ZoneId.systemDefault()),
                dayStartMinutes = dayStartMinutes,
                nightStartMinutes = nightStartMinutes
            )
        }
    }

    val resolvedPrimary = remember(accentPalette, customHexColor) {
        if (!customHexColor.isNullOrBlank() && HexColorValidator.isValidHex(customHexColor)) {
            HexColorValidator.parseColorOrDefault(customHexColor, accentPalette.primaryColor)
        } else {
            accentPalette.primaryColor
        }
    }
    val resolvedOnPrimary = remember(resolvedPrimary) {
        HexColorValidator.accessibleOnColor(resolvedPrimary)
    }
    val resolvedSecondary = remember(accentPalette, customHexColor, resolvedPrimary) {
        if (!customHexColor.isNullOrBlank() && HexColorValidator.isValidHex(customHexColor)) {
            resolvedPrimary.copy(alpha = 0.85f)
        } else {
            accentPalette.secondaryColor
        }
    }
    val resolvedOnSecondary = remember(resolvedSecondary) {
        HexColorValidator.accessibleOnColor(resolvedSecondary)
    }

    val semanticColors = remember(isDarkTheme, resolvedPrimary, resolvedOnPrimary, resolvedSecondary, resolvedOnSecondary) {
        if (isDarkTheme) {
            FitGoSemanticColors(
                primary = resolvedPrimary,
                onPrimary = resolvedOnPrimary,
                secondary = resolvedSecondary,
                onSecondary = resolvedOnSecondary,
                background = FitGoDesignTokens.NightBackground,
                onBackground = FitGoDesignTokens.NightOnBackground,
                surface = FitGoDesignTokens.NightSurface,
                onSurface = FitGoDesignTokens.NightOnSurface,
                surfaceVariant = FitGoDesignTokens.NightSurfaceVariant,
                onSurfaceVariant = FitGoDesignTokens.NightOnSurfaceVariant,
                outline = FitGoDesignTokens.NightOutline,
                error = FitGoDesignTokens.ErrorNight,
                success = FitGoDesignTokens.SuccessNight,
                warning = FitGoDesignTokens.WarningNight,
                isDark = true
            )
        } else {
            FitGoSemanticColors(
                primary = resolvedPrimary,
                onPrimary = resolvedOnPrimary,
                secondary = resolvedSecondary,
                onSecondary = resolvedOnSecondary,
                background = FitGoDesignTokens.DayBackground,
                onBackground = FitGoDesignTokens.DayOnBackground,
                surface = FitGoDesignTokens.DaySurface,
                onSurface = FitGoDesignTokens.DayOnSurface,
                surfaceVariant = FitGoDesignTokens.DaySurfaceVariant,
                onSurfaceVariant = FitGoDesignTokens.DayOnSurfaceVariant,
                outline = FitGoDesignTokens.DayOutline,
                error = FitGoDesignTokens.ErrorDay,
                success = FitGoDesignTokens.SuccessDay,
                warning = FitGoDesignTokens.WarningDay,
                isDark = false
            )
        }
    }

    val materialColorScheme: ColorScheme = remember(semanticColors) {
        if (semanticColors.isDark) {
            darkColorScheme(
                primary = semanticColors.primary,
                onPrimary = semanticColors.onPrimary,
                secondary = semanticColors.secondary,
                onSecondary = semanticColors.onSecondary,
                background = semanticColors.background,
                onBackground = semanticColors.onBackground,
                surface = semanticColors.surface,
                onSurface = semanticColors.onSurface,
                surfaceVariant = semanticColors.surfaceVariant,
                onSurfaceVariant = semanticColors.onSurfaceVariant,
                outline = semanticColors.outline,
                error = semanticColors.error
            )
        } else {
            lightColorScheme(
                primary = semanticColors.primary,
                onPrimary = semanticColors.onPrimary,
                secondary = semanticColors.secondary,
                onSecondary = semanticColors.onSecondary,
                background = semanticColors.background,
                onBackground = semanticColors.onBackground,
                surface = semanticColors.surface,
                onSurface = semanticColors.onSurface,
                surfaceVariant = semanticColors.surfaceVariant,
                onSurfaceVariant = semanticColors.onSurfaceVariant,
                outline = semanticColors.outline,
                error = semanticColors.error
            )
        }
    }

    CompositionLocalProvider(LocalFitGoColors provides semanticColors) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            typography = FitGoTypography,
            content = content
        )
    }
}
