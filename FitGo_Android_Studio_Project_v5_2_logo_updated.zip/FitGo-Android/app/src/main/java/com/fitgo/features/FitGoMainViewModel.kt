package com.fitgo.features

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitgo.core.design.AccentPalette
import com.fitgo.core.design.ThemeMode
import com.fitgo.core.utils.DistanceUnit
import com.fitgo.core.utils.LengthUnit
import com.fitgo.core.utils.PlateCalculator
import com.fitgo.core.utils.PlateLoadResult
import com.fitgo.core.utils.RestTimerState
import com.fitgo.core.utils.WeightUnit
import com.fitgo.data.backup.BackupAndCsvManager
import com.fitgo.data.backup.RestoreSummary
import com.fitgo.data.database.entities.BodyMeasurementEntity
import com.fitgo.data.database.entities.ExerciseCategory
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.ExerciseType
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity
import com.fitgo.data.database.entities.SetType
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutSetEntity
import com.fitgo.data.repositories.FitGoRepository
import com.fitgo.data.repositories.UserPreferencesRepository
import com.fitgo.data.repositories.UserSettingsState
import com.fitgo.domain.models.ActiveWorkoutExerciseBlock
import com.fitgo.domain.models.CompletedWorkoutSummary
import com.fitgo.domain.models.DashboardMetrics
import com.fitgo.features.billing.PlayBillingManager
import com.fitgo.features.notifications.RestTimerNotifier
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class FitGoMainViewModel @Inject constructor(
    private val repository: FitGoRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val backupAndCsvManager: BackupAndCsvManager,
    private val restTimerNotifier: RestTimerNotifier,
    val playBillingManager: PlayBillingManager
) : ViewModel() {

    val settingsState: StateFlow<UserSettingsState> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserSettingsState())

    val dashboardMetrics: StateFlow<DashboardMetrics?> = repository.observeDashboardMetrics()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val exercises: StateFlow<List<ExerciseEntity>> = repository.activeExercisesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val finishedWorkouts: StateFlow<List<WorkoutEntity>> = repository.finishedWorkoutsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unfinishedWorkout: StateFlow<WorkoutEntity?> = repository.unfinishedWorkoutFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val personalRecords: StateFlow<List<PersonalRecordEntity>> = repository.personalRecordsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val routines: StateFlow<List<RoutineEntity>> = repository.routinesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bodyMeasurements: StateFlow<List<BodyMeasurementEntity>> = repository.bodyMeasurementsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeWorkoutBlocks = MutableStateFlow<List<ActiveWorkoutExerciseBlock>>(emptyList())
    val activeWorkoutBlocks: StateFlow<List<ActiveWorkoutExerciseBlock>> = _activeWorkoutBlocks.asStateFlow()

    private val _lastDeletedSet = MutableStateFlow<WorkoutSetEntity?>(null)
    val lastDeletedSet: StateFlow<WorkoutSetEntity?> = _lastDeletedSet.asStateFlow()

    private val _lastCompletedSummary = MutableStateFlow<CompletedWorkoutSummary?>(null)
    val lastCompletedSummary: StateFlow<CompletedWorkoutSummary?> = _lastCompletedSummary.asStateFlow()

    private val _restTimerState = MutableStateFlow(RestTimerState())
    val restTimerState: StateFlow<RestTimerState> = _restTimerState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeedDataLoaded()
            playBillingManager.startConnection()
        }
        viewModelScope.launch {
            unfinishedWorkout.collect { active ->
                if (active != null) refreshActiveWorkoutBlocks(active.id)
                else _activeWorkoutBlocks.value = emptyList()
            }
        }
        viewModelScope.launch {
            while (true) {
                val current = _restTimerState.value
                if (current.isRunning && current.isFinished()) {
                    val prefs = settingsState.value
                    restTimerNotifier.triggerTimerCompletedAlert(
                        soundEnabled = prefs.restTimerSoundEnabled,
                        vibrationEnabled = prefs.restTimerVibrationEnabled
                    )
                    _restTimerState.value = current.copy(isRunning = false, targetEndEpochMillis = null)
                }
                delay(250L)
            }
        }
    }

    private suspend fun refreshActiveWorkoutBlocks(workoutId: String) {
        val includeOverload = settingsState.value.enableOverloadSuggestions
        _activeWorkoutBlocks.value = repository.loadActiveExerciseBlocks(workoutId, includeOverload)
    }

    fun startWorkout(title: String = "Strength Workout", routineId: String? = null) {
        viewModelScope.launch {
            val wk = repository.startNewWorkout(title, routineId)
            refreshActiveWorkoutBlocks(wk.id)
        }
    }

    fun addExerciseToActiveWorkout(exerciseId: String) {
        val wk = unfinishedWorkout.value ?: return
        viewModelScope.launch {
            repository.addExerciseToWorkout(wk.id, exerciseId)
            refreshActiveWorkoutBlocks(wk.id)
        }
    }

    fun createSupersetGroup(firstExerciseId: String, secondExerciseId: String) {
        val workout = unfinishedWorkout.value ?: return
        viewModelScope.launch {
            runCatching { repository.createSupersetGroup(workout.id, firstExerciseId, secondExerciseId) }
            refreshActiveWorkoutBlocks(workout.id)
        }
    }

    fun removeSupersetGroup(workoutId: String, groupId: String) {
        viewModelScope.launch {
            repository.removeSupersetGroup(workoutId, groupId)
            refreshActiveWorkoutBlocks(workoutId)
        }
    }

    fun addSetToExercise(block: ActiveWorkoutExerciseBlock) {
        viewModelScope.launch {
            val nextOrder = (block.sets.maxOfOrNull { it.setOrder } ?: 0) + 1
            val template = block.sets.lastOrNull() ?: block.previousSessionSets.firstOrNull()
            val newSet = WorkoutSetEntity(
                id = "ws_${UUID.randomUUID()}",
                workoutExerciseId = block.workoutExercise.id,
                workoutId = block.workoutExercise.workoutId,
                exerciseId = block.exercise.id,
                setOrder = nextOrder,
                setType = SetType.NORMAL,
                weightKg = template?.weightKg ?: 20.0,
                reps = template?.reps ?: 10,
                isCompleted = false
            )
            repository.saveOrUpdateSet(newSet)
            refreshActiveWorkoutBlocks(block.workoutExercise.workoutId)
        }
    }

    fun updateSet(set: WorkoutSetEntity, triggerRestOnComplete: Boolean = true) {
        viewModelScope.launch {
            val updated = if (set.isCompleted && set.completedAtEpochMillis == null) {
                set.copy(completedAtEpochMillis = System.currentTimeMillis())
            } else set
            repository.saveOrUpdateSet(updated)
            refreshActiveWorkoutBlocks(set.workoutId)
            if (triggerRestOnComplete && updated.isCompleted) {
                startRestTimer(settingsState.value.defaultRestSeconds)
            }
        }
    }

    fun deleteSetWithUndo(set: WorkoutSetEntity) {
        viewModelScope.launch {
            _lastDeletedSet.value = set
            repository.deleteSet(set)
            refreshActiveWorkoutBlocks(set.workoutId)
        }
    }

    fun undoDeleteSet() {
        val deleted = _lastDeletedSet.value ?: return
        viewModelScope.launch {
            repository.saveOrUpdateSet(deleted)
            _lastDeletedSet.value = null
            refreshActiveWorkoutBlocks(deleted.workoutId)
        }
    }

    fun finishActiveWorkout(notes: String) {
        val wk = unfinishedWorkout.value ?: return
        viewModelScope.launch {
            _lastCompletedSummary.value = repository.finishWorkoutSession(wk.id, notes)
        }
    }

    fun dismissWorkoutSummary() {
        _lastCompletedSummary.value = null
    }

    fun cancelActiveWorkout() {
        val wk = unfinishedWorkout.value ?: return
        viewModelScope.launch { repository.cancelActiveWorkout(wk.id) }
    }

    fun startRestTimer(durationSeconds: Int = settingsState.value.defaultRestSeconds) {
        _restTimerState.value = RestTimerState.start(durationSeconds)
    }

    fun pauseRestTimer() {
        _restTimerState.value = RestTimerState.pause(_restTimerState.value)
    }

    fun resumeRestTimer() {
        _restTimerState.value = RestTimerState.resume(_restTimerState.value)
    }

    fun adjustRestTimerSeconds(deltaSeconds: Int) {
        _restTimerState.value = RestTimerState.adjustSeconds(_restTimerState.value, deltaSeconds)
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun updateAccentPalette(palette: AccentPalette) {
        viewModelScope.launch { preferencesRepository.setAccentPalette(palette) }
    }

    fun updateCustomHexColor(hex: String?) {
        viewModelScope.launch { preferencesRepository.setCustomHexColor(hex) }
    }

    fun updateAutoSchedule(dayStartMinutes: Int, nightStartMinutes: Int) {
        viewModelScope.launch { preferencesRepository.setAutoThemeSchedule(dayStartMinutes, nightStartMinutes) }
    }

    fun resetAppearance() {
        viewModelScope.launch { preferencesRepository.resetAppearanceToDefault() }
    }

    fun updateUnits(weight: WeightUnit, distance: DistanceUnit, length: LengthUnit) {
        viewModelScope.launch { preferencesRepository.setUnits(weight, distance, length) }
    }

    fun updateLanguage(languageCode: String) {
        viewModelScope.launch { preferencesRepository.setLanguageCode(languageCode) }
    }

    fun calculatePlates(targetWeight: Double, barWeight: Double): PlateLoadResult {
        val denoms = if (settingsState.value.weightUnit == WeightUnit.KG) {
            PlateCalculator.DEFAULT_PLATES_KG
        } else {
            PlateCalculator.DEFAULT_PLATES_LBS
        }
        return PlateCalculator.calculatePerSide(targetWeight, barWeight, denoms)
    }

    fun toggleFavouriteExercise(exerciseId: String, currentFav: Boolean) {
        viewModelScope.launch { repository.toggleFavouriteExercise(exerciseId, currentFav) }
    }

    fun saveRoutine(name: String, description: String, exerciseIds: List<String>) {
        val cleanName = name.trim()
        val uniqueIds = exerciseIds.distinct()
        if (cleanName.isBlank() || uniqueIds.isEmpty()) return
        viewModelScope.launch {
            repository.saveRoutine(
                id = null,
                name = cleanName,
                description = description.trim(),
                exercises = uniqueIds.mapIndexed { index, exerciseId ->
                    RoutineExerciseEntity(
                        id = "", routineId = "", exerciseId = exerciseId, orderIndex = index,
                        targetSets = 3, targetReps = 10, restDurationSeconds = settingsState.value.defaultRestSeconds
                    )
                }
            )
        }
    }

    fun deleteRoutine(routine: RoutineEntity) {
        viewModelScope.launch { repository.deleteRoutine(routine.id) }
    }

    fun saveBodyMeasurement(measurement: BodyMeasurementEntity) {
        val hasValue = listOf(
            measurement.bodyWeightKg, measurement.chestCm, measurement.waistCm,
            measurement.hipsCm, measurement.armsCm, measurement.thighsCm
        ).any { it != null && it > 0.0 }
        if (hasValue) viewModelScope.launch { repository.saveBodyMeasurement(measurement) }
    }

    fun deleteBodyMeasurement(measurement: BodyMeasurementEntity) {
        viewModelScope.launch { repository.deleteBodyMeasurement(measurement.id) }
    }

    suspend fun exportEncryptedBackup(password: CharArray): ByteArray =
        backupAndCsvManager.createEncryptedBackupBytes(password)

    suspend fun restoreEncryptedBackup(bytes: ByteArray, password: CharArray): RestoreSummary =
        backupAndCsvManager.validateAndRestoreEncryptedBackup(bytes, password)

    suspend fun exportWorkoutHistoryCsv(): String = backupAndCsvManager.exportWorkoutHistoryCsv()
}
