package com.fitgo.features.workout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.AccessibleStatusBadge
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.utils.RestTimerState
import com.fitgo.core.utils.UnitConverter
import com.fitgo.data.database.entities.ExerciseCategory
import com.fitgo.data.database.entities.SetType
import com.fitgo.features.routines.RoutineBuilderCard
import com.fitgo.features.FitGoMainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkoutTrackerScreen(viewModel: FitGoMainViewModel) {
    val activeWorkout by viewModel.unfinishedWorkout.collectAsState()
    val blocks by viewModel.activeWorkoutBlocks.collectAsState()
    val exercises by viewModel.exercises.collectAsState()
    val restTimer by viewModel.restTimerState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val summary by viewModel.lastCompletedSummary.collectAsState()
    val lastDeleted by viewModel.lastDeletedSet.collectAsState()
    val routines by viewModel.routines.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<ExerciseCategory?>(null) }
    var workoutNotes by remember { mutableStateOf("") }
    var supersetSelectionId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        summary?.let { completed ->
            item {
                FitGoCard {
                    AccessibleStatusBadge(label = "Workout Completed & Saved", isSuccess = true)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = completed.workout.title, style = MaterialTheme.typography.headlineMedium)
                    Text(
                        text = "Exercises: ${completed.exerciseCount} • Completed Sets: ${completed.completedSetsCount} • Volume: ${UnitConverter.formatVolume(completed.totalVolumeKg, settings.weightUnit)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (completed.achievedPrs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "New Personal Records: ${completed.achievedPrs.size} (Est. 1RM via Epley Formula)",
                            style = MaterialTheme.typography.titleMedium,
                            color = LocalFitGoColors.current.success
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.dismissWorkoutSummary() }) { Text("Dismiss Summary") }
                }
            }
        }

        item {
            FitGoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, contentDescription = "Rest Timer", tint = LocalFitGoColors.current.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Rest Timer: ${restTimer.remainingSeconds()}s", style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { viewModel.adjustRestTimerSeconds(-15) }) { Text("-15s") }
                        TextButton(onClick = { viewModel.adjustRestTimerSeconds(15) }) { Text("+15s") }
                        if (restTimer.isRunning) {
                            OutlinedButton(onClick = { viewModel.pauseRestTimer() }) { Text("Pause") }
                        } else if (restTimer.isPaused) {
                            Button(onClick = { viewModel.resumeRestTimer() }) { Text("Resume") }
                        } else {
                            Button(onClick = { viewModel.startRestTimer() }) { Text("Start") }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RestTimerState.PRESET_DURATIONS_SECONDS.forEach { preset ->
                        FilterChip(
                            selected = restTimer.totalDurationSeconds == preset,
                            onClick = { viewModel.startRestTimer(preset) },
                            label = { Text("${preset}s") }
                        )
                    }
                }
            }
        }

        item {
            if (settings.isProEntitled) {
                RoutineBuilderCard(
                    routines = routines,
                    exercises = exercises,
                    onSaveRoutine = viewModel::saveRoutine,
                    onStartRoutine = { routine -> viewModel.startWorkout(routine.name, routine.id) },
                    onDeleteRoutine = viewModel::deleteRoutine
                )
            } else {
                FitGoCard {
                    Text("Custom Routines — Pro", style = MaterialTheme.typography.titleLarge)
                    Text("Build your own exercise sequence and start it with one tap after unlocking Lifetime Pro.")
                }
            }
        }

        if (activeWorkout == null) {
            item {
                FitGoCard {
                    Text("No Active Session", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Start a blank workout or select from the Exercise Library below.")
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(onClick = { viewModel.startWorkout("Strength Session") }) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start New Workout")
                    }
                }
            }
        } else {
            item {
                FitGoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = activeWorkout!!.title, style = MaterialTheme.typography.headlineMedium)
                            Text(
                                text = "Autosaved locally • Volume: ${UnitConverter.formatVolume(activeWorkout!!.totalVolumeKg, settings.weightUnit)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = LocalFitGoColors.current.onSurfaceVariant
                            )
                        }
                        AccessibleStatusBadge(label = "Autosave Active", isSuccess = true)
                    }
                    if (lastDeleted != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Set deleted.", style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = { viewModel.undoDeleteSet() }) { Text("Undo") }
                        }
                    }
                }
            }

            items(blocks, key = { it.workoutExercise.id }) { block ->
                FitGoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = block.exercise.name, style = MaterialTheme.typography.titleLarge)
                            Text(
                                text = "${block.exercise.category.displayNameEn} • ${block.exercise.equipment}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = LocalFitGoColors.current.onSurfaceVariant
                            )
                        }
                        block.workoutExercise.supersetGroupId?.let { ss ->
                            AccessibleStatusBadge(label = "Superset")
                        }
                    }
                    if (block.workoutExercise.supersetGroupId == null) {
                        TextButton(onClick = {
                            val selected = supersetSelectionId
                            if (selected == null) supersetSelectionId = block.workoutExercise.id
                            else if (selected == block.workoutExercise.id) supersetSelectionId = null
                            else {
                                viewModel.createSupersetGroup(selected, block.workoutExercise.id)
                                supersetSelectionId = null
                            }
                        }) {
                            Text(if (supersetSelectionId == block.workoutExercise.id) "Selected — tap another exercise" else "Pair as Superset")
                        }
                    } else {
                        TextButton(onClick = { viewModel.removeSupersetGroup(block.workoutExercise.workoutId, block.workoutExercise.supersetGroupId!!) }) {
                            Text("Unpair Superset")
                        }
                    }

                    block.overloadSuggestion?.let { suggestion ->
                        Spacer(modifier = Modifier.height(8.dp))
                        AccessibleStatusBadge(label = suggestion.headlineEn, isSuccess = true)
                        Text(
                            text = suggestion.rationaleEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = LocalFitGoColors.current.onSurfaceVariant
                        )
                    }

                    if (block.previousSessionSets.isNotEmpty()) {
                        val prev = block.previousSessionSets.first()
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Previous Session Best: ${UnitConverter.formatWeight(prev.weightKg, settings.weightUnit)} × ${prev.reps} reps",
                            style = MaterialTheme.typography.labelLarge,
                            color = LocalFitGoColors.current.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    block.sets.forEach { setItem ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    val nextIdx = (SetType.entries.indexOf(setItem.setType) + 1) % SetType.entries.size
                                    viewModel.updateSet(setItem.copy(setType = SetType.entries[nextIdx]), false)
                                }
                            ) {
                                Text("${setItem.setOrder} [${setItem.setType.badgeCode}]")
                            }
                            Text(
                                text = "${UnitConverter.formatWeight(setItem.weightKg, settings.weightUnit)} × ${setItem.reps} reps",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { viewModel.updateSet(setItem.copy(weightKg = setItem.weightKg + 2.5), false) }) { Text("+2.5") }
                                TextButton(onClick = { viewModel.updateSet(setItem.copy(reps = setItem.reps + 1), false) }) { Text("+1r") }
                                Checkbox(
                                    checked = setItem.isCompleted,
                                    onCheckedChange = { checked ->
                                        viewModel.updateSet(setItem.copy(isCompleted = checked), triggerRestOnComplete = checked)
                                    }
                                )
                                IconButton(onClick = { viewModel.deleteSetWithUndo(setItem) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Set")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = { viewModel.addSetToExercise(block) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Set")
                    }
                }
            }

            item {
                FitGoCard {
                    OutlinedTextField(
                        value = workoutNotes,
                        onValueChange = { workoutNotes = it },
                        label = { Text("Workout Session Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.finishActiveWorkout(workoutNotes) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Finish Workout")
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(onClick = { viewModel.cancelActiveWorkout() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cancel Workout Safely", color = LocalFitGoColors.current.error)
                    }
                }
            }
        }

        item {
            Text("Exercise Library (${exercises.size})", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search exercises by name, muscle, or equipment") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = selectedCategory == null, onClick = { selectedCategory = null }, label = { Text("All") })
                ExerciseCategory.entries.forEach { cat ->
                    FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat }, label = { Text(cat.displayNameEn) })
                }
            }
        }

        val filtered = exercises.filter { ex ->
            (selectedCategory == null || ex.category == selectedCategory) &&
                (searchQuery.isBlank() ||
                    ex.name.contains(searchQuery, ignoreCase = true) ||
                    ex.primaryMuscle.contains(searchQuery, ignoreCase = true))
        }

        items(filtered, key = { it.id }) { ex ->
            FitGoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = ex.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${ex.category.displayNameEn} • ${ex.primaryMuscle} • ${ex.equipment}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = LocalFitGoColors.current.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { viewModel.toggleFavouriteExercise(ex.id, ex.isFavourite) }) {
                        Icon(
                            imageVector = if (ex.isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favourite",
                            tint = if (ex.isFavourite) LocalFitGoColors.current.primary else LocalFitGoColors.current.onSurfaceVariant
                        )
                    }
                    if (activeWorkout != null) {
                        Button(onClick = { viewModel.addExerciseToActiveWorkout(ex.id) }) { Text("Add") }
                    }
                }
            }
        }
    }
}
