package com.fitgo.core.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import kotlin.math.max
import kotlin.math.min

enum class AccentPalette(
    val id: String,
    val displayNameEn: String,
    val displayNameHi: String,
    val hexCode: String,
    val primaryColor: Color,
    val secondaryColor: Color
) {
    FITGO_VIOLET("VIOLET", "FitGo Violet", "फ़िटगो वायलेट", "#7654E8", Color(0xFF7654E8), Color(0xFF5E3FD1)),
    OCEAN_BLUE("OCEAN_BLUE", "Ocean Blue", "ओशन ब्लू", "#1976D2", Color(0xFF1976D2), Color(0xFF0288D1)),
    EMERALD_GREEN("EMERALD", "Emerald Green", "एमराल्ड ग्रीन", "#159B72", Color(0xFF159B72), Color(0xFF0E7C5A)),
    ROYAL_PURPLE("ROYAL_PURPLE", "Royal Purple", "रॉयल पर्पल", "#7045BD", Color(0xFF7045BD), Color(0xFF5A32A3)),
    SUNSET_ORANGE("SUNSET_ORANGE", "Sunset Orange", "सनसेट ऑरेंज", "#E87935", Color(0xFFE87935), Color(0xFFD15E1C)),
    ROSE_PINK("ROSE_PINK", "Rose Pink", "रोज़ पिंक", "#D94F91", Color(0xFFD94F91), Color(0xFFB83775)),
    CRIMSON_RED("CRIMSON_RED", "Crimson Red", "क्रिमसन रेड", "#D94343", Color(0xFFD94343), Color(0xFFB82E2E)),
    TEAL("TEAL", "Teal", "टील", "#008F95", Color(0xFF008F95), Color(0xFF006E73));

    companion object {
        fun fromId(id: String): AccentPalette = entries.firstOrNull { it.id == id } ?: FITGO_VIOLET
    }
}

object HexColorValidator {
    private val HEX_REGEX = Regex("^#?([A-Fa-f0-9]{6})$")

    fun isValidHex(input: String): Boolean = HEX_REGEX.matches(input.trim())

    fun normalizeHex(input: String): String? {
        val match = HEX_REGEX.find(input.trim()) ?: return null
        return "#${match.groupValues[1].uppercase()}"
    }

    fun parseColorOrDefault(input: String?, fallback: Color = AccentPalette.FITGO_VIOLET.primaryColor): Color {
        if (input.isNullOrBlank()) return fallback
        val normalized = normalizeHex(input) ?: return fallback
        return try {
            val rgb = normalized.substring(1).toLong(16)
            Color(0xFF000000 or rgb)
        } catch (e: NumberFormatException) {
            fallback
        }
    }

    /**
     * Computes accessible OnPrimary color (White or Deep Slate) based on WCAG relative luminance.
     */
    fun accessibleOnColor(background: Color): Color {
        val lum = background.luminance()
        val contrastWithWhite = (1.0f + 0.05f) / (lum + 0.05f)
        val contrastWithDark = (lum + 0.05f) / (0.015f + 0.05f)
        return if (contrastWithWhite >= 4.5f || contrastWithWhite >= contrastWithDark) {
            Color(0xFFFFFFFF)
        } else {
            Color(0xFF0F172A)
        }
    }

    fun contrastRatio(c1: Color, c2: Color): Float {
        val l1 = max(c1.luminance(), c2.luminance())
        val l2 = min(c1.luminance(), c2.luminance())
        return (l1 + 0.05f) / (l2 + 0.05f)
    }
}

// Separately engineered Light (Day) and Dark (Night) Surfaces & Semantic Tokens
object FitGoDesignTokens {
    // Day Mode Surfaces (Clean White & Soft Off-White)
    val DayBackground = Color(0xFFF7F9FC)
    val DayOnBackground = Color(0xFF0F172A)
    val DaySurface = Color(0xFFFFFFFF)
    val DayOnSurface = Color(0xFF1E293B)
    val DaySurfaceVariant = Color(0xFFEEF2F7)
    val DayOnSurfaceVariant = Color(0xFF475569)
    val DayOutline = Color(0xFFCBD5E1)

    // Night Mode Surfaces (Deep Charcoal & Low-Light Optimized Slate — Not Simply Inverted)
    val NightBackground = Color(0xFF0B0F17)
    val NightOnBackground = Color(0xFFF1F5F9)
    val NightSurface = Color(0xFF141B26)
    val NightOnSurface = Color(0xFFE2E8F0)
    val NightSurfaceVariant = Color(0xFF1E2736)
    val NightOnSurfaceVariant = Color(0xFF94A3B8)
    val NightOutline = Color(0xFF334155)

    // Semantic Status Tokens (Day / Night pairs)
    val SuccessDay = Color(0xFF15803D)
    val SuccessNight = Color(0xFF4ADE80)
    val WarningDay = Color(0xFFB45309)
    val WarningNight = Color(0xFFFBBF24)
    val ErrorDay = Color(0xFFB91C1C)
    val ErrorNight = Color(0xFFF87171)
}
