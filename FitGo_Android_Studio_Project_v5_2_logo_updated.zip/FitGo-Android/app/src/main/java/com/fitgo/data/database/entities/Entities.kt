package com.fitgo.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class ExerciseCategory(val displayNameEn: String, val displayNameHi: String) {
    CHEST("Chest", "छाती (Chest)"),
    BACK("Back", "पीठ (Back)"),
    SHOULDERS("Shoulders", "कंधे (Shoulders)"),
    BICEPS("Biceps", "बाइसेप्स (Biceps)"),
    TRICEPS("Triceps", "ट्राइसेप्स (Triceps)"),
    LEGS("Legs", "पैर (Legs)"),
    GLUTES("Glutes", "ग्लूट्स (Glutes)"),
    ABS("Abs", "एब्स (Abs)"),
    FOREARMS("Forearms", "फोरआर्म्स (Forearms)"),
    CARDIO("Cardio", "कार्डियो (Cardio)"),
    FULL_BODY("Full Body", "फुल बॉडी (Full Body)")
}

enum class ExerciseType {
    WEIGHT_AND_REPS,
    BODYWEIGHT_REPS,
    DURATION_ONLY,
    DISTANCE_AND_DURATION
}

enum class SetType(val badgeCode: String, val labelEn: String, val labelHi: String) {
    NORMAL("N", "Normal Set", "सामान्य सेट"),
    WARMUP("W", "Warm-up Set", "वार्म-अप सेट"),
    DROP("D", "Drop Set", "ड्रॉप सेट"),
    FAILURE("F", "Failure Set", "फेलियर सेट"),
    REST_PAUSE("RP", "Rest-Pause Set", "रेस्ट-पॉज़ सेट")
}

@Serializable
@Entity(
    tableName = "exercises",
    indices = [Index("category"), Index("isFavourite"), Index("isArchived")]
)
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val nameHi: String = "",
    val category: ExerciseCategory,
    val primaryMuscle: String,
    val secondaryMusclesCsv: String,
    val equipment: String,
    val instructions: String,
    val exerciseType: ExerciseType = ExerciseType.WEIGHT_AND_REPS,
    val illustrationKey: String = "barbell_default",
    val isFavourite: Boolean = false,
    val isCustom: Boolean = false,
    val isArchived: Boolean = false,
    val lastUsedEpochMillis: Long? = null
)

@Serializable
@Entity(
    tableName = "workouts",
    indices = [Index("startedAtEpochMillis"), Index("isFinished")]
)
data class WorkoutEntity(
    @PrimaryKey val id: String,
    val title: String,
    val routineId: String? = null,
    val startedAtEpochMillis: Long,
    val finishedAtEpochMillis: Long? = null,
    val durationSeconds: Long = 0L,
    val notes: String = "",
    val totalVolumeKg: Double = 0.0,
    val totalCompletedSets: Int = 0,
    val prCountAchieved: Int = 0,
    val isFinished: Boolean = false,
    val lastAutosavedAtEpochMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "workout_exercises",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutEntity::class,
            parentColumns = ["id"],
            childColumns = ["workoutId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ExerciseEntity::class,
            parentColumns = ["id"],
            childColumns = ["exerciseId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("workoutId"), Index("exerciseId")]
)
data class WorkoutExerciseEntity(
    @PrimaryKey val id: String,
    val workoutId: String,
    val exerciseId: String,
    val orderIndex: Int,
    val notes: String = "",
    val supersetGroupId: String? = null
)

@Serializable
@Entity(
    tableName = "workout_sets",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutExerciseEntity::class,
            parentColumns = ["id"],
            childColumns = ["workoutExerciseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("workoutExerciseId"), Index("exerciseId")]
)
data class WorkoutSetEntity(
    @PrimaryKey val id: String,
    val workoutExerciseId: String,
    val workoutId: String,
    val exerciseId: String,
    val setOrder: Int,
    val setType: SetType = SetType.NORMAL,
    val weightKg: Double = 0.0,
    val reps: Int = 0,
    val durationSeconds: Int? = null,
    val distanceKm: Double? = null,
    val isCompleted: Boolean = false,
    val completedAtEpochMillis: Long? = null
)

@Serializable
@Entity(
    tableName = "personal_records",
    indices = [Index("exerciseId"), Index("achievedAtEpochMillis")]
)
data class PersonalRecordEntity(
    @PrimaryKey val id: String,
    val exerciseId: String,
    val workoutId: String,
    val maxWeightKg: Double,
    val maxRepsAtWeight: Int,
    val estimatedOneRepMaxKg: Double?,
    val highestSetVolumeKg: Double,
    val achievedAtEpochMillis: Long
)

@Serializable
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val isSampleRoutine: Boolean = false,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "routine_exercises",
    foreignKeys = [
        ForeignKey(
            entity = RoutineEntity::class,
            parentColumns = ["id"],
            childColumns = ["routineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("routineId"), Index("exerciseId")]
)
data class RoutineExerciseEntity(
    @PrimaryKey val id: String,
    val routineId: String,
    val exerciseId: String,
    val orderIndex: Int,
    val targetSets: Int = 3,
    val targetReps: Int = 10,
    val restDurationSeconds: Int = 90,
    val supersetGroupId: String? = null,
    val notes: String = ""
)

@Serializable
@Entity(
    tableName = "body_measurements",
    indices = [Index("recordedAtEpochMillis")]
)
data class BodyMeasurementEntity(
    @PrimaryKey val id: String,
    val recordedAtEpochMillis: Long,
    val bodyWeightKg: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val hipsCm: Double? = null,
    val armsCm: Double? = null,
    val thighsCm: Double? = null,
    val customLabel: String? = null,
    val customValueCm: Double? = null,
    val notes: String = ""
)
