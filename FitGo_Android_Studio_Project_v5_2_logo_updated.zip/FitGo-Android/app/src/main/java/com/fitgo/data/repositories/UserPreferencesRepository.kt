package com.fitgo.data.repositories

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.fitgo.core.design.AccentPalette
import com.fitgo.core.design.HexColorValidator
import com.fitgo.core.design.ThemeMode
import com.fitgo.core.utils.DistanceUnit
import com.fitgo.core.utils.LengthUnit
import com.fitgo.core.utils.WeightUnit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fitgo_preferences")

data class UserSettingsState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentPalette: AccentPalette = AccentPalette.FITGO_VIOLET,
    val customHexColor: String? = null,
    val dayStartMinutes: Int = 6 * 60,    // 06:00 AM
    val nightStartMinutes: Int = 18 * 60, // 06:00 PM
    val weightUnit: WeightUnit = WeightUnit.KG,
    val distanceUnit: DistanceUnit = DistanceUnit.KM,
    val lengthUnit: LengthUnit = LengthUnit.CM,
    val defaultRestSeconds: Int = 90,
    val enableOverloadSuggestions: Boolean = true,
    val restTimerSoundEnabled: Boolean = true,
    val restTimerVibrationEnabled: Boolean = true,
    val maxRestDaysForStreak: Int = 2,
    val languageCode: String = "en",
    val proPurchaseTokenHash: String? = null,
    val proOrderId: String? = null,
    val proVerifiedAtEpochMillis: Long = 0L
) {
    /**
     * Pro entitlement is never stored as a bare boolean flag; it requires a verified Play Billing
     * purchase token hash and order signature record cached after BillingClient verification.
     */
    val isProEntitled: Boolean
        get() = !proPurchaseTokenHash.isNullOrBlank() && proVerifiedAtEpochMillis > 0L
}

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_PALETTE = stringPreferencesKey("accent_palette")
        val CUSTOM_HEX = stringPreferencesKey("custom_hex_color")
        val DAY_START_MIN = intPreferencesKey("day_start_minutes")
        val NIGHT_START_MIN = intPreferencesKey("night_start_minutes")
        val WEIGHT_UNIT = stringPreferencesKey("weight_unit")
        val DISTANCE_UNIT = stringPreferencesKey("distance_unit")
        val LENGTH_UNIT = stringPreferencesKey("length_unit")
        val DEFAULT_REST_SEC = intPreferencesKey("default_rest_seconds")
        val ENABLE_OVERLOAD = booleanPreferencesKey("enable_overload_suggestions")
        val TIMER_SOUND = booleanPreferencesKey("timer_sound_enabled")
        val TIMER_VIBRATE = booleanPreferencesKey("timer_vibration_enabled")
        val STREAK_REST_DAYS = intPreferencesKey("streak_rest_days")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val PRO_TOKEN_HASH = stringPreferencesKey("pro_purchase_token_hash")
        val PRO_ORDER_ID = stringPreferencesKey("pro_order_id")
        val PRO_VERIFIED_AT = longPreferencesKey("pro_verified_at_epoch_millis")
    }

    val settingsFlow: Flow<UserSettingsState> = context.dataStore.data.map { prefs ->
        UserSettingsState(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            accentPalette = AccentPalette.fromId(prefs[Keys.ACCENT_PALETTE] ?: AccentPalette.FITGO_VIOLET.id),
            customHexColor = prefs[Keys.CUSTOM_HEX],
            dayStartMinutes = prefs[Keys.DAY_START_MIN] ?: (6 * 60),
            nightStartMinutes = prefs[Keys.NIGHT_START_MIN] ?: (18 * 60),
            weightUnit = prefs[Keys.WEIGHT_UNIT]?.let { runCatching { WeightUnit.valueOf(it) }.getOrNull() }
                ?: WeightUnit.KG,
            distanceUnit = prefs[Keys.DISTANCE_UNIT]?.let { runCatching { DistanceUnit.valueOf(it) }.getOrNull() }
                ?: DistanceUnit.KM,
            lengthUnit = prefs[Keys.LENGTH_UNIT]?.let { runCatching { LengthUnit.valueOf(it) }.getOrNull() }
                ?: LengthUnit.CM,
            defaultRestSeconds = prefs[Keys.DEFAULT_REST_SEC] ?: 90,
            enableOverloadSuggestions = prefs[Keys.ENABLE_OVERLOAD] ?: true,
            restTimerSoundEnabled = prefs[Keys.TIMER_SOUND] ?: true,
            restTimerVibrationEnabled = prefs[Keys.TIMER_VIBRATE] ?: true,
            maxRestDaysForStreak = prefs[Keys.STREAK_REST_DAYS] ?: 2,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
            proPurchaseTokenHash = prefs[Keys.PRO_TOKEN_HASH],
            proOrderId = prefs[Keys.PRO_ORDER_ID],
            proVerifiedAtEpochMillis = prefs[Keys.PRO_VERIFIED_AT] ?: 0L
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAccentPalette(palette: AccentPalette) {
        context.dataStore.edit {
            it[Keys.ACCENT_PALETTE] = palette.id
            it.remove(Keys.CUSTOM_HEX)
        }
    }

    suspend fun setCustomHexColor(hex: String?) {
        val normalized = hex?.let { HexColorValidator.normalizeHex(it) }
        context.dataStore.edit {
            if (normalized != null) {
                it[Keys.CUSTOM_HEX] = normalized
            } else {
                it.remove(Keys.CUSTOM_HEX)
            }
        }
    }

    suspend fun setAutoThemeSchedule(dayStartMinutes: Int, nightStartMinutes: Int) {
        context.dataStore.edit {
            it[Keys.DAY_START_MIN] = dayStartMinutes.coerceIn(0, 1439)
            it[Keys.NIGHT_START_MIN] = nightStartMinutes.coerceIn(0, 1439)
        }
    }

    suspend fun resetAppearanceToDefault() {
        context.dataStore.edit {
            it[Keys.THEME_MODE] = ThemeMode.SYSTEM.name
            it[Keys.ACCENT_PALETTE] = AccentPalette.FITGO_VIOLET.id
            it.remove(Keys.CUSTOM_HEX)
            it[Keys.DAY_START_MIN] = 6 * 60
            it[Keys.NIGHT_START_MIN] = 18 * 60
        }
    }

    suspend fun setUnits(weightUnit: WeightUnit, distanceUnit: DistanceUnit, lengthUnit: LengthUnit) {
        context.dataStore.edit {
            it[Keys.WEIGHT_UNIT] = weightUnit.name
            it[Keys.DISTANCE_UNIT] = distanceUnit.name
            it[Keys.LENGTH_UNIT] = lengthUnit.name
        }
    }

    suspend fun setWorkoutPreferences(
        defaultRestSeconds: Int,
        enableOverload: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        context.dataStore.edit {
            it[Keys.DEFAULT_REST_SEC] = defaultRestSeconds.coerceIn(15, 600)
            it[Keys.ENABLE_OVERLOAD] = enableOverload
            it[Keys.TIMER_SOUND] = soundEnabled
            it[Keys.TIMER_VIBRATE] = vibrationEnabled
        }
    }

    suspend fun setLanguageCode(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_CODE] = if (code == "hi") "hi" else "en" }
    }

    suspend fun cacheVerifiedProEntitlement(purchaseTokenHash: String, orderId: String?, verifiedAtMillis: Long) {
        context.dataStore.edit {
            it[Keys.PRO_TOKEN_HASH] = purchaseTokenHash
            if (orderId != null) it[Keys.PRO_ORDER_ID] = orderId else it.remove(Keys.PRO_ORDER_ID)
            it[Keys.PRO_VERIFIED_AT] = verifiedAtMillis
        }
    }

    suspend fun clearProEntitlement() {
        context.dataStore.edit {
            it.remove(Keys.PRO_TOKEN_HASH)
            it.remove(Keys.PRO_ORDER_ID)
            it.remove(Keys.PRO_VERIFIED_AT)
        }
    }
}
