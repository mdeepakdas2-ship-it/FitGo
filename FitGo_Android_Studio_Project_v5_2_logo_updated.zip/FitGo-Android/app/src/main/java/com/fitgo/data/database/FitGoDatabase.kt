package com.fitgo.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.fitgo.data.database.dao.FitGoDao
import com.fitgo.data.database.entities.BodyMeasurementEntity
import com.fitgo.data.database.entities.ExerciseCategory
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.ExerciseType
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity
import com.fitgo.data.database.entities.SetType
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutExerciseEntity
import com.fitgo.data.database.entities.WorkoutSetEntity

class FitGoTypeConverters {
    @TypeConverter
    fun fromCategory(cat: ExerciseCategory): String = cat.name

    @TypeConverter
    fun toCategory(value: String): ExerciseCategory =
        runCatching { ExerciseCategory.valueOf(value) }.getOrDefault(ExerciseCategory.FULL_BODY)

    @TypeConverter
    fun fromExerciseType(type: ExerciseType): String = type.name

    @TypeConverter
    fun toExerciseType(value: String): ExerciseType =
        runCatching { ExerciseType.valueOf(value) }.getOrDefault(ExerciseType.WEIGHT_AND_REPS)

    @TypeConverter
    fun fromSetType(type: SetType): String = type.name

    @TypeConverter
    fun toSetType(value: String): SetType =
        runCatching { SetType.valueOf(value) }.getOrDefault(SetType.NORMAL)
}

@Database(
    entities = [
        ExerciseEntity::class,
        WorkoutEntity::class,
        WorkoutExerciseEntity::class,
        WorkoutSetEntity::class,
        PersonalRecordEntity::class,
        RoutineEntity::class,
        RoutineExerciseEntity::class,
        BodyMeasurementEntity::class
    ],
    version = 5,
    exportSchema = true
)
@TypeConverters(FitGoTypeConverters::class)
abstract class FitGoDatabase : RoomDatabase() {
    abstract fun fitGoDao(): FitGoDao
}
