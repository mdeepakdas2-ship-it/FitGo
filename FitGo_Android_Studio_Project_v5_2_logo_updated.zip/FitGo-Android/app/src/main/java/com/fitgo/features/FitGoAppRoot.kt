package com.fitgo.features

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.fitgo.core.design.FitGoTheme
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.navigation.PrimaryTab
import com.fitgo.features.analytics.AnalyticsDashboardScreen
import com.fitgo.features.history.WorkoutHistoryScreen
import com.fitgo.features.home.HomeDashboardScreen
import com.fitgo.features.settings.SettingsAndAppearanceScreen
import com.fitgo.features.workout.WorkoutTrackerScreen

@Composable
fun FitGoAppRoot(viewModel: FitGoMainViewModel) {
    val settings by viewModel.settingsState.collectAsState()
    val navController = rememberNavController()
    val isHindi = settings.languageCode == "hi"

    FitGoTheme(
        themeMode = settings.themeMode,
        accentPalette = settings.accentPalette,
        customHexColor = settings.customHexColor,
        dayStartMinutes = settings.dayStartMinutes,
        nightStartMinutes = settings.nightStartMinutes
    ) {
        val colors = LocalFitGoColors.current
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: PrimaryTab.HOME.route

        Scaffold(
            containerColor = colors.background,
            bottomBar = {
                NavigationBar(containerColor = colors.surface, contentColor = colors.onSurface) {
                    PrimaryTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = if (isHindi) tab.titleHi else tab.titleEn) },
                            label = { Text(if (isHindi) tab.titleHi else tab.titleEn) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = PrimaryTab.HOME.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                composable(PrimaryTab.HOME.route) {
                    HomeDashboardScreen(
                        viewModel = viewModel,
                        onNavigateToWorkout = { navController.navigate(PrimaryTab.WORKOUT.route) }
                    )
                }
                composable(PrimaryTab.WORKOUT.route) { WorkoutTrackerScreen(viewModel = viewModel) }
                composable(PrimaryTab.HISTORY.route) { WorkoutHistoryScreen(viewModel = viewModel) }
                composable(PrimaryTab.ANALYTICS.route) { AnalyticsDashboardScreen(viewModel = viewModel) }
                composable(PrimaryTab.SETTINGS.route) { SettingsAndAppearanceScreen(viewModel = viewModel) }
            }
        }
    }
}
