package com.fitgo.features.analytics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.FitGoLineChart
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.utils.UnitConverter
import com.fitgo.features.FitGoMainViewModel
import com.fitgo.features.measurements.BodyMeasurementsCard

@Composable
fun AnalyticsDashboardScreen(viewModel: FitGoMainViewModel) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val prs by viewModel.personalRecords.collectAsState()
    val exercises by viewModel.exercises.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val bodyMeasurements by viewModel.bodyMeasurements.collectAsState()
    val exercisesById = remember(exercises) { exercises.associateBy { it.id } }

    var plateTargetWeight by remember { mutableStateOf("100") }
    var plateBarWeight by remember { mutableStateOf("20") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Analytics, PR Engine & Tools", style = MaterialTheme.typography.headlineLarge)
            Text(
                text = "Estimated 1RM values use the Epley formula: Weight × (1 + Reps / 30). Explicitly labeled as an estimate, not an actual tested maximum.",
                style = MaterialTheme.typography.bodyMedium,
                color = LocalFitGoColors.current.onSurfaceVariant
            )
        }

        item {
            val weekly = metrics?.weeklyVolumeByDay.orEmpty()
            FitGoCard {
                Text("7-Day Volume Trend", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(10.dp))
                FitGoLineChart(points = weekly, accessibilityTitle = "7-Day Volume Progression Line Chart")
            }
        }

        item {
            val target = plateTargetWeight.toDoubleOrNull()
            val bar = plateBarWeight.toDoubleOrNull()
            val result = if (target != null && bar != null) viewModel.calculatePlates(target, bar)
                else viewModel.calculatePlates(Double.NaN, Double.NaN)
            FitGoCard {
                Text("Barbell Plate Calculator (${settings.weightUnit.symbol})", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = plateTargetWeight,
                        onValueChange = { plateTargetWeight = it },
                        label = { Text("Target (${settings.weightUnit.symbol})") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = plateBarWeight,
                        onValueChange = { plateBarWeight = it },
                        label = { Text("Bar (${settings.weightUnit.symbol})") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = when {
                        !result.isValid -> result.errorMessage ?: "Invalid plate calculation"
                        result.perSidePlates.isEmpty() -> "Bar only (${result.barWeight} ${settings.weightUnit.symbol})"
                        else -> "Per Side Load: " + result.perSidePlates.joinToString(", ") { "${it.second}×${it.first}${settings.weightUnit.symbol}" }
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = if (result.isValid) LocalFitGoColors.current.primary else MaterialTheme.colorScheme.error
                )
                if (result.isValid && result.remainderUnloaded > 0.0001) {
                    Text("Closest achievable load: ${result.achievableWeight} ${settings.weightUnit.symbol}. Unloaded remainder: ${"%.2f".format(result.remainderUnloaded)} ${settings.weightUnit.symbol}.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            if (settings.isProEntitled) {
                BodyMeasurementsCard(
                    records = bodyMeasurements,
                    onSaveMeasurement = viewModel::saveBodyMeasurement,
                    onDeleteMeasurement = viewModel::deleteBodyMeasurement
                )
            } else {
                FitGoCard {
                    Text("Body Progress Tracking — Pro", style = MaterialTheme.typography.titleLarge)
                    Text("Track weight and body measurements over time with Lifetime Pro.")
                }
            }
        }

        item {
            Text("Personal Records Timeline (${prs.size})", style = MaterialTheme.typography.titleLarge)
        }

        items(prs, key = { it.id }) { pr ->
            val exName = exercisesById[pr.exerciseId]?.name ?: pr.exerciseId
            FitGoCard {
                Text(text = exName, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Max Load: ${UnitConverter.formatWeight(pr.maxWeightKg, settings.weightUnit)} × ${pr.maxRepsAtWeight} reps",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
                pr.estimatedOneRepMaxKg?.let { est ->
                    Text(
                        text = "Est. 1RM (Epley Estimate): ${UnitConverter.formatWeight(est, settings.weightUnit)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LocalFitGoColors.current.primary
                    )
                }
            }
        }
    }
}
