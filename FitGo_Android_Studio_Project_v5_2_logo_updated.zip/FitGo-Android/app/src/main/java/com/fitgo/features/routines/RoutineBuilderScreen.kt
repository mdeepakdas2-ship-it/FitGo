package com.fitgo.features.routines

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.FitGoCard
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.RoutineEntity

@Composable
fun RoutineBuilderCard(
    routines: List<RoutineEntity>,
    exercises: List<ExerciseEntity>,
    onSaveRoutine: (String, String, List<String>) -> Unit,
    onStartRoutine: (RoutineEntity) -> Unit,
    onDeleteRoutine: (RoutineEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var showDelete by remember { mutableStateOf<RoutineEntity?>(null) }

    FitGoCard {
        Text("My Workout Routines", style = MaterialTheme.typography.titleLarge)
        Text("Create a reusable workout. Select exercises, save it, then start it with one tap.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Routine name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(description, { description = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(search, { search = it }, label = { Text("Find exercises") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("Choose exercises (${selectedIds.size} selected)", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            exercises.filter { it.name.contains(search, ignoreCase = true) }.take(12).forEach { exercise ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(checked = exercise.id in selectedIds, onCheckedChange = { checked ->
                        selectedIds = if (checked) selectedIds + exercise.id else selectedIds - exercise.id
                    })
                    Column(Modifier.weight(1f)) {
                        Text(exercise.name, style = MaterialTheme.typography.bodyMedium)
                        Text(exercise.category.displayNameEn, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { onSaveRoutine(name.trim(), description.trim(), selectedIds.toList()); name = ""; description = ""; selectedIds = emptySet() },
            enabled = name.isNotBlank() && selectedIds.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save Routine") }
        Spacer(Modifier.height(12.dp))
        Text("Saved routines", style = MaterialTheme.typography.titleMedium)
        if (routines.isEmpty()) Text("No routines yet. Create your first routine above.", style = MaterialTheme.typography.bodyMedium)
        routines.forEach { routine ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(routine.name, style = MaterialTheme.typography.titleSmall)
                    if (routine.description.isNotBlank()) Text(routine.description, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { onStartRoutine(routine) }) { Text("Start") }
                if (!routine.isSampleRoutine) TextButton(onClick = { showDelete = routine }) { Text("Delete") }
            }
        }
    }
    showDelete?.let { routine ->
        AlertDialog(
            onDismissRequest = { showDelete = null },
            title = { Text("Delete routine?") },
            text = { Text("${routine.name} will be removed. Past workouts will remain unchanged.") },
            confirmButton = { TextButton(onClick = { onDeleteRoutine(routine); showDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { showDelete = null }) { Text("Cancel") } }
        )
    }
}
