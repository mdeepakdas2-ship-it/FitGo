package com.fitgo.features.timer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.utils.RestTimerState

@Composable
fun RestTimerControlsCard(
    timerState: RestTimerState,
    onStartPreset: (Int) -> Unit,
    onAdjustSeconds: (Int) -> Unit,
    onReset: () -> Unit
) {
    FitGoCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Rest Timer: ${timerState.remainingSeconds()}s",
                style = MaterialTheme.typography.titleLarge
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onAdjustSeconds(-15) }) { Text("-15s") }
                OutlinedButton(onClick = { onAdjustSeconds(15) }) { Text("+15s") }
                Button(onClick = onReset) { Text("Reset") }
            }
        }
    }
}
