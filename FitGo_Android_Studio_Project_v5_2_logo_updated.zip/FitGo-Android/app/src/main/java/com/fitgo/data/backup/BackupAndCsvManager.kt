package com.fitgo.data.backup

import com.fitgo.core.security.CryptoManager
import com.fitgo.data.database.dao.FitGoDao
import com.fitgo.data.database.entities.BodyMeasurementEntity
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutExerciseEntity
import com.fitgo.data.database.entities.WorkoutSetEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class FitGoBackupPayload(
    val schemaVersion: Int = 5,
    val appVersionName: String = "5.1.0",
    val exportedAtEpochMillis: Long,
    val exercises: List<ExerciseEntity>,
    val workouts: List<WorkoutEntity>,
    val workoutExercises: List<WorkoutExerciseEntity>,
    val workoutSets: List<WorkoutSetEntity>,
    val personalRecords: List<PersonalRecordEntity>,
    val routines: List<RoutineEntity>,
    val routineExercises: List<RoutineExerciseEntity>,
    val bodyMeasurements: List<BodyMeasurementEntity>,
    val payloadChecksumSha256: String = ""
)

data class RestoreSummary(
    val workoutsRestored: Int,
    val exercisesRestored: Int,
    val personalRecordsRestored: Int,
    val safetySnapshotBytes: ByteArray
)

@Singleton
class BackupAndCsvManager @Inject constructor(
    private val dao: FitGoDao
) {
    private val json = Json {
        prettyPrint = false
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun createEncryptedBackupBytes(password: CharArray): ByteArray {
        val rawPayload = buildCurrentPayload()
        val canonicalForHash = json.encodeToString(rawPayload.copy(payloadChecksumSha256 = ""))
        val checksum = CryptoManager.sha256Hex(canonicalForHash)
        val signedPayload = rawPayload.copy(payloadChecksumSha256 = checksum)
        val serialized = json.encodeToString(signedPayload)
        return CryptoManager.encryptBackupPayload(serialized, password)
    }

    suspend fun validateAndRestoreEncryptedBackup(
        encryptedBytes: ByteArray,
        password: CharArray
    ): RestoreSummary {
        val decryptedJson = CryptoManager.decryptBackupPayload(encryptedBytes, password)
        val parsed = json.decodeFromString<FitGoBackupPayload>(decryptedJson)

        require(parsed.schemaVersion in 1..5) {
            "Unsupported backup schema version: ${parsed.schemaVersion}"
        }

        val canonicalForHash = json.encodeToString(parsed.copy(payloadChecksumSha256 = ""))
        val computedHash = CryptoManager.sha256Hex(canonicalForHash)
        require(computedHash.equals(parsed.payloadChecksumSha256, ignoreCase = true)) {
            "Backup checksum verification failed. File may be corrupted."
        }

        // Deduplicate primary keys defensively before transactional restore
        val cleanExercises = parsed.exercises.distinctBy { it.id }
        val cleanWorkouts = parsed.workouts.distinctBy { it.id }
        val cleanWorkoutExercises = parsed.workoutExercises.distinctBy { it.id }
        val cleanSets = parsed.workoutSets.distinctBy { it.id }
        val cleanPrs = parsed.personalRecords.distinctBy { it.id }
        val cleanRoutines = parsed.routines.distinctBy { it.id }
        val cleanRoutineExercises = parsed.routineExercises.distinctBy { it.id }
        val cleanMeasurements = parsed.bodyMeasurements.distinctBy { it.id }

        // Create pre-restore safety snapshot encrypted with the same session password
        val snapshotPassword = password.clone()
        val safetySnapshot = try {
            createEncryptedBackupBytes(snapshotPassword)
        } finally {
            snapshotPassword.fill('\u0000')
        }

        dao.replaceEntireDatabaseTransactionally(
            exercises = cleanExercises,
            workouts = cleanWorkouts,
            workoutExercises = cleanWorkoutExercises,
            workoutSets = cleanSets,
            personalRecords = cleanPrs,
            routines = cleanRoutines,
            routineExercises = cleanRoutineExercises,
            bodyMeasurements = cleanMeasurements
        )

        return RestoreSummary(
            workoutsRestored = cleanWorkouts.size,
            exercisesRestored = cleanExercises.size,
            personalRecordsRestored = cleanPrs.size,
            safetySnapshotBytes = safetySnapshot
        )
    }

    private suspend fun buildCurrentPayload(): FitGoBackupPayload {
        return FitGoBackupPayload(
            schemaVersion = 5,
            appVersionName = "5.1.0",
            exportedAtEpochMillis = System.currentTimeMillis(),
            exercises = dao.getAllExercisesOnce(),
            workouts = dao.getAllWorkoutsOnce(),
            workoutExercises = dao.getAllWorkoutExercisesOnce(),
            workoutSets = dao.getAllWorkoutSetsOnce(),
            personalRecords = dao.getAllPersonalRecordsOnce(),
            routines = dao.getAllRoutinesOnce(),
            routineExercises = dao.getAllRoutineExercisesOnce(),
            bodyMeasurements = dao.getAllBodyMeasurementsOnce()
        )
    }

    // RFC-4180 Compliant CSV Escaping & Export
    fun escapeCsvField(value: String?): String {
        if (value == null) return ""
        val needsQuotes = value.contains(',') || value.contains('"') || value.contains('\n') || value.contains('\r')
        return if (needsQuotes) {
            "\"${value.replace("\"", "\"\"")}\""
        } else {
            value
        }
    }

    suspend fun exportWorkoutHistoryCsv(): String {
        val workouts = dao.getAllWorkoutsOnce().filter { it.isFinished }.sortedByDescending { it.startedAtEpochMillis }
        val exercisesById = dao.getAllExercisesOnce().associateBy { it.id }
        val sets = dao.getAllWorkoutSetsOnce().groupBy { it.workoutId }
        val sb = StringBuilder()
        sb.appendLine("Workout ID,Date ISO,Workout Title,Duration (sec),Exercise Name,Set Order,Set Type,Weight (kg),Reps,Distance (km),Duration Set (sec),Completed,Workout Notes")

        val isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.systemDefault())
        for (workout in workouts) {
            val dateStr = isoFormatter.format(Instant.ofEpochMilli(workout.startedAtEpochMillis))
            val workoutSets = sets[workout.id].orEmpty().sortedBy { it.setOrder }
            if (workoutSets.isEmpty()) {
                sb.appendLine(
                    listOf(
                        workout.id, dateStr, workout.title, workout.durationSeconds.toString(),
                        "", "", "", "", "", "", "", "true", workout.notes
                    ).joinToString(",") { escapeCsvField(it) }
                )
            } else {
                for (s in workoutSets) {
                    val exName = exercisesById[s.exerciseId]?.name ?: s.exerciseId
                    sb.appendLine(
                        listOf(
                            workout.id,
                            dateStr,
                            workout.title,
                            workout.durationSeconds.toString(),
                            exName,
                            s.setOrder.toString(),
                            s.setType.name,
                            "%.2f".format(s.weightKg),
                            s.reps.toString(),
                            s.distanceKm?.let { "%.2f".format(it) } ?: "",
                            s.durationSeconds?.toString() ?: "",
                            s.isCompleted.toString(),
                            workout.notes
                        ).joinToString(",") { escapeCsvField(it) }
                    )
                }
            }
        }
        return sb.toString()
    }

    suspend fun exportPersonalRecordsCsv(): String {
        val prs = dao.getAllPersonalRecordsOnce().sortedByDescending { it.achievedAtEpochMillis }
        val exercisesById = dao.getAllExercisesOnce().associateBy { it.id }
        val isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE.withZone(ZoneId.systemDefault())
        val sb = StringBuilder()
        sb.appendLine("Record ID,Date,Exercise Name,Max Weight (kg),Reps at Max Weight,Estimated 1RM (kg - Epley),Highest Set Volume (kg)")
        for (pr in prs) {
            val exName = exercisesById[pr.exerciseId]?.name ?: pr.exerciseId
            val dateStr = isoFormatter.format(Instant.ofEpochMilli(pr.achievedAtEpochMillis))
            sb.appendLine(
                listOf(
                    pr.id,
                    dateStr,
                    exName,
                    "%.2f".format(pr.maxWeightKg),
                    pr.maxRepsAtWeight.toString(),
                    pr.estimatedOneRepMaxKg?.let { "%.2f".format(it) } ?: "N/A",
                    "%.2f".format(pr.highestSetVolumeKg)
                ).joinToString(",") { escapeCsvField(it) }
            )
        }
        return sb.toString()
    }

    suspend fun exportBodyMeasurementsCsv(): String {
        val items = dao.getAllBodyMeasurementsOnce().sortedByDescending { it.recordedAtEpochMillis }
        val isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE.withZone(ZoneId.systemDefault())
        val sb = StringBuilder()
        sb.appendLine("Measurement ID,Date,Body Weight (kg),Chest (cm),Waist (cm),Hips (cm),Arms (cm),Thighs (cm),Custom Label,Custom Value (cm),Notes")
        for (m in items) {
            val dateStr = isoFormatter.format(Instant.ofEpochMilli(m.recordedAtEpochMillis))
            sb.appendLine(
                listOf(
                    m.id,
                    dateStr,
                    m.bodyWeightKg?.toString() ?: "",
                    m.chestCm?.toString() ?: "",
                    m.waistCm?.toString() ?: "",
                    m.hipsCm?.toString() ?: "",
                    m.armsCm?.toString() ?: "",
                    m.thighsCm?.toString() ?: "",
                    m.customLabel ?: "",
                    m.customValueCm?.toString() ?: "",
                    m.notes
                ).joinToString(",") { escapeCsvField(it) }
            )
        }
        return sb.toString()
    }
}
