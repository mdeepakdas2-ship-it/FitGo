package com.fitgo.features.appearance

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.fitgo.core.design.AccentPalette
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.ThemeMode

@Composable
fun AppearancePreviewBanner(
    themeMode: ThemeMode,
    accentPalette: AccentPalette,
    customHex: String?
) {
    FitGoCard {
        Text(
            text = "Active Theme: ${themeMode.name} • Accent: ${customHex ?: accentPalette.displayNameEn}",
            style = MaterialTheme.typography.titleMedium
        )
    }
}
