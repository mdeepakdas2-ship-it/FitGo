package com.fitgo.features.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.fitgo.core.security.CryptoManager
import com.fitgo.BuildConfig
import android.util.Base64
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import org.json.JSONObject
import com.fitgo.data.repositories.UserPreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class BillingStatus {
    DISCONNECTED,
    READY,
    PURCHASE_PENDING,
    PURCHASE_VERIFIED,
    PURCHASE_SIGNATURE_INVALID,
    USER_CANCELLED,
    PLAY_CONSOLE_CONFIG_REQUIRED,
    ERROR
}

@Singleton
class PlayBillingManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferencesRepository: UserPreferencesRepository
) : PurchasesUpdatedListener {

    companion object {
        const val PRO_LIFETIME_PRODUCT_ID = "fitgo_pro_lifetime"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _billingStatus = MutableStateFlow(BillingStatus.DISCONNECTED)
    val billingStatus: StateFlow<BillingStatus> = _billingStatus.asStateFlow()

    private val _localizedPrice = MutableStateFlow("Price shown by Google Play")
    val localizedPrice: StateFlow<String> = _localizedPrice.asStateFlow()

    private var proProductDetails: ProductDetails? = null

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
        )
        .build()

    fun startConnection() {
        if (billingClient.isReady) {
            queryProductAndRestorePurchases()
            return
        }
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    _billingStatus.value = BillingStatus.READY
                    queryProductAndRestorePurchases()
                } else {
                    _billingStatus.value = BillingStatus.PLAY_CONSOLE_CONFIG_REQUIRED
                }
            }

            override fun onBillingServiceDisconnected() {
                _billingStatus.value = BillingStatus.DISCONNECTED
            }
        })
    }

    private fun queryProductAndRestorePurchases() {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRO_LIFETIME_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        )
        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
        billingClient.queryProductDetailsAsync(params) { result, detailsList ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK && detailsList.isNotEmpty()) {
                val detail = detailsList.first()
                proProductDetails = detail
                detail.oneTimePurchaseOfferDetails?.formattedPrice?.let {
                    _localizedPrice.value = it
                }
            } else {
                _billingStatus.value = BillingStatus.PLAY_CONSOLE_CONFIG_REQUIRED
            }
        }
        restorePurchases()
    }

    fun launchLifetimeProPurchaseFlow(activity: Activity) {
        val details = proProductDetails
        if (details == null) {
            _billingStatus.value = BillingStatus.PLAY_CONSOLE_CONFIG_REQUIRED
            return
        }
        val productDetailsParams = listOf(
            BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)
                .build()
        )
        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(productDetailsParams)
            .build()
        billingClient.launchBillingFlow(activity, flowParams)
    }

    fun restorePurchases() {
        if (!billingClient.isReady) {
            startConnection()
            return
        }
        val queryParams = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        billingClient.queryPurchasesAsync(queryParams) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                val lifetimePurchase = purchases.firstOrNull { it.products.contains(PRO_LIFETIME_PRODUCT_ID) }
                if (lifetimePurchase == null) {
                    scope.launch { preferencesRepository.clearProEntitlement() }
                } else {
                    processPurchase(lifetimePurchase)
                }
            }
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases?.forEach { processPurchase(it) }
            BillingClient.BillingResponseCode.USER_CANCELED -> _billingStatus.value = BillingStatus.USER_CANCELLED
            else -> _billingStatus.value = BillingStatus.ERROR
        }
    }

    private fun processPurchase(purchase: Purchase) {
        if (!purchase.products.contains(PRO_LIFETIME_PRODUCT_ID)) return
        when (purchase.purchaseState) {
            Purchase.PurchaseState.PURCHASED -> {
                // Never unlock Pro based only on a locally generated token hash.
                // Verify Google's signed purchase payload with the app's Play Console public key first.
                if (!verifyPurchaseSignature(purchase)) {
                    scope.launch { preferencesRepository.clearProEntitlement() }
                    _billingStatus.value = if (BuildConfig.FITGO_PLAY_PUBLIC_KEY.isBlank()) {
                        BillingStatus.PLAY_CONSOLE_CONFIG_REQUIRED
                    } else BillingStatus.PURCHASE_SIGNATURE_INVALID
                    return
                }
                if (!purchase.isAcknowledged) {
                    val ackParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()
                    billingClient.acknowledgePurchase(ackParams) { ackResult ->
                        if (ackResult.responseCode == BillingClient.BillingResponseCode.OK) {
                            persistVerifiedPurchase(purchase)
                        } else {
                            _billingStatus.value = BillingStatus.ERROR
                        }
                    }
                } else {
                    persistVerifiedPurchase(purchase)
                }
            }
            Purchase.PurchaseState.PENDING -> _billingStatus.value = BillingStatus.PURCHASE_PENDING
            else -> Unit
        }
    }

    private fun verifyPurchaseSignature(purchase: Purchase): Boolean {
        val encodedPublicKey = BuildConfig.FITGO_PLAY_PUBLIC_KEY.trim()
        if (encodedPublicKey.isBlank() || purchase.originalJson.isBlank() || purchase.signature.isBlank()) return false
        return runCatching {
            val payload = JSONObject(purchase.originalJson)
            require(payload.optString("packageName") == BuildConfig.APPLICATION_ID)
            require(payload.optString("productId") == PRO_LIFETIME_PRODUCT_ID)
            val keyBytes = Base64.decode(encodedPublicKey, Base64.DEFAULT)
            val publicKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(keyBytes))
            val verifier = Signature.getInstance("SHA1withRSA")
            verifier.initVerify(publicKey)
            verifier.update(purchase.originalJson.toByteArray(Charsets.UTF_8))
            verifier.verify(Base64.decode(purchase.signature, Base64.DEFAULT))
        }.getOrDefault(false)
    }

    private fun persistVerifiedPurchase(purchase: Purchase) {
        scope.launch {
            val tokenHash = CryptoManager.sha256Hex("${purchase.purchaseToken}:${purchase.signature}")
            preferencesRepository.cacheVerifiedProEntitlement(
                purchaseTokenHash = tokenHash,
                orderId = purchase.orderId,
                verifiedAtMillis = System.currentTimeMillis()
            )
            _billingStatus.value = BillingStatus.PURCHASE_VERIFIED
        }
    }
}
