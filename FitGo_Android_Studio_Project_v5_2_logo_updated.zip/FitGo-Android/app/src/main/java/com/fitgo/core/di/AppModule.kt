package com.fitgo.core.di

import android.content.Context
import androidx.room.Room
import com.fitgo.data.database.FitGoDatabase
import com.fitgo.data.database.dao.FitGoDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideFitGoDatabase(@ApplicationContext context: Context): FitGoDatabase {
        return Room.databaseBuilder(
            context,
            FitGoDatabase::class.java,
            "fitgo_local_workout.db"
        )
            // Never silently wipe a user's workout history during an upgrade.
            // Add explicit Room migrations before shipping any schema version change.
            .build()
    }

    @Provides
    @Singleton
    fun provideFitGoDao(db: FitGoDatabase): FitGoDao = db.fitGoDao()
}
