package com.fitgo.features.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.AccessibleStatusBadge
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.utils.UnitConverter
import com.fitgo.features.FitGoMainViewModel

@Composable
fun WorkoutHistoryScreen(viewModel: FitGoMainViewModel) {
    val workouts by viewModel.finishedWorkouts.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Workout History & Calendar", style = MaterialTheme.typography.headlineLarge)
            Text(
                text = "All workout sessions are stored 100% locally in your SQLite database.",
                style = MaterialTheme.typography.bodyMedium,
                color = LocalFitGoColors.current.onSurfaceVariant
            )
        }
        if (workouts.isEmpty()) {
            item {
                FitGoCard {
                    Text("No Completed Workouts Yet", style = MaterialTheme.typography.titleMedium)
                    Text("Finish a session in the Workout tab to see your full training log and calendar history.")
                }
            }
        } else {
            items(workouts, key = { it.id }) { workout ->
                FitGoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = workout.title, style = MaterialTheme.typography.titleLarge)
                        AccessibleStatusBadge(label = "${workout.totalCompletedSets} Sets", isSuccess = true)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Total Volume: ${UnitConverter.formatVolume(workout.totalVolumeKg, settings.weightUnit)} • Duration: ${workout.durationSeconds / 60} min • PRs: ${workout.prCountAchieved}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (workout.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Notes: ${workout.notes}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = LocalFitGoColors.current.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
