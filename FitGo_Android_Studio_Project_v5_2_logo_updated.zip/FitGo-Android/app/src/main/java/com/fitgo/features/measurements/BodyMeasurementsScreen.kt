package com.fitgo.features.measurements

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.FitGoCard
import com.fitgo.data.database.entities.BodyMeasurementEntity
import java.text.DateFormat
import java.util.UUID
import java.util.Date

@Composable
fun BodyMeasurementsCard(
    records: List<BodyMeasurementEntity>,
    onSaveMeasurement: (BodyMeasurementEntity) -> Unit,
    onDeleteMeasurement: (BodyMeasurementEntity) -> Unit
) {
    var weight by remember { mutableStateOf("") }
    var waist by remember { mutableStateOf("") }
    var chest by remember { mutableStateOf("") }
    var hips by remember { mutableStateOf("") }
    var arms by remember { mutableStateOf("") }
    var thighs by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<BodyMeasurementEntity?>(null) }

    FitGoCard {
        Text("Body Progress", style = MaterialTheme.typography.titleLarge)
        Text("Record measurements over time. Leave fields blank when you do not have a measurement.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        MeasurementField(weight, { weight = it }, "Body weight (kg)")
        MeasurementField(waist, { waist = it }, "Waist (cm)")
        MeasurementField(chest, { chest = it }, "Chest (cm)")
        MeasurementField(hips, { hips = it }, "Hips (cm)")
        MeasurementField(arms, { arms = it }, "Arms (cm)")
        MeasurementField(thighs, { thighs = it }, "Thighs (cm)")
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                onSaveMeasurement(
                    BodyMeasurementEntity(
                        id = "bm_${UUID.randomUUID()}",
                        recordedAtEpochMillis = System.currentTimeMillis(),
                        bodyWeightKg = weight.toDoubleOrNull(), chestCm = chest.toDoubleOrNull(),
                        waistCm = waist.toDoubleOrNull(), hipsCm = hips.toDoubleOrNull(),
                        armsCm = arms.toDoubleOrNull(), thighsCm = thighs.toDoubleOrNull(), notes = notes.trim()
                    )
                )
                weight = ""; waist = ""; chest = ""; hips = ""; arms = ""; thighs = ""; notes = ""
            },
            enabled = listOf(weight, waist, chest, hips, arms, thighs).any { it.toDoubleOrNull()?.let { v -> v > 0 } == true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save Measurement") }
        Spacer(Modifier.height(14.dp))
        Text("Measurement history (${records.size})", style = MaterialTheme.typography.titleMedium)
        if (records.isEmpty()) Text("Your saved progress entries will appear here.", style = MaterialTheme.typography.bodyMedium)
        records.forEach { record ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(record.recordedAtEpochMillis)), style = MaterialTheme.typography.labelMedium)
                val values = buildList {
                    record.bodyWeightKg?.let { add("Weight ${it} kg") }
                    record.waistCm?.let { add("Waist ${it} cm") }
                    record.chestCm?.let { add("Chest ${it} cm") }
                    record.hipsCm?.let { add("Hips ${it} cm") }
                    record.armsCm?.let { add("Arms ${it} cm") }
                    record.thighsCm?.let { add("Thighs ${it} cm") }
                }
                Text(values.joinToString(" • "), style = MaterialTheme.typography.bodyMedium)
                if (record.notes.isNotBlank()) Text(record.notes, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { deleteTarget = record }) { Text("Delete entry") }
            }
        }
    }
    deleteTarget?.let { record ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete measurement?") },
            text = { Text("This progress entry will be permanently removed from this device.") },
            confirmButton = { TextButton(onClick = { onDeleteMeasurement(record); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MeasurementField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { input -> if (input.isEmpty() || input.matches(Regex("^\\d{0,4}(\\.\\d{0,2})?$"))) onValueChange(input) },
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true
    )
}
