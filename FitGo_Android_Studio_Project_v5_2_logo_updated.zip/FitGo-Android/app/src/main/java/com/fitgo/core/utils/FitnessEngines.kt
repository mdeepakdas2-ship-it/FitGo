package com.fitgo.core.utils

import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

enum class WeightUnit(val symbol: String) { KG("kg"), LBS("lbs") }
enum class DistanceUnit(val symbol: String) { KM("km"), MI("mi") }
enum class LengthUnit(val symbol: String) { CM("cm"), IN("in") }

/**
 * Lossless unit conversion utility.
 * Canonical storage in FitGo Database is always Metric (kg, km, cm) so changing display units
 * never mutates underlying historical records.
 */
object UnitConverter {
    private const val KG_TO_LBS = 2.20462262185
    private const val KM_TO_MI = 0.62137119224
    private const val CM_TO_IN = 0.3937007874

    fun kgToDisplay(weightKg: Double, unit: WeightUnit): Double =
        when (unit) {
            WeightUnit.KG -> weightKg
            WeightUnit.LBS -> weightKg * KG_TO_LBS
        }

    fun displayToKg(displayWeight: Double, unit: WeightUnit): Double =
        when (unit) {
            WeightUnit.KG -> displayWeight
            WeightUnit.LBS -> displayWeight / KG_TO_LBS
        }

    fun kmToDisplay(distanceKm: Double, unit: DistanceUnit): Double =
        when (unit) {
            DistanceUnit.KM -> distanceKm
            DistanceUnit.MI -> distanceKm * KM_TO_MI
        }

    fun displayToKm(displayDistance: Double, unit: DistanceUnit): Double =
        when (unit) {
            DistanceUnit.KM -> displayDistance
            DistanceUnit.MI -> displayDistance / KM_TO_MI
        }

    fun cmToDisplay(lengthCm: Double, unit: LengthUnit): Double =
        when (unit) {
            LengthUnit.CM -> lengthCm
            LengthUnit.IN -> lengthCm * CM_TO_IN
        }

    fun displayToCm(displayLength: Double, unit: LengthUnit): Double =
        when (unit) {
            LengthUnit.CM -> displayLength
            LengthUnit.IN -> displayLength / CM_TO_IN
        }

    fun formatWeight(weightKg: Double, unit: WeightUnit, locale: Locale = Locale.getDefault()): String {
        val converted = kgToDisplay(weightKg, unit)
        val nf = NumberFormat.getNumberInstance(locale).apply {
            maximumFractionDigits = 1
            minimumFractionDigits = if (abs(converted - converted.roundToInt()) < 0.05) 0 else 1
        }
        return "${nf.format(converted)} ${unit.symbol}"
    }

    fun formatVolume(volumeKg: Double, unit: WeightUnit, locale: Locale = Locale.getDefault()): String {
        val converted = kgToDisplay(volumeKg, unit)
        val nf = NumberFormat.getNumberInstance(locale).apply {
            maximumFractionDigits = 0
        }
        return "${nf.format(converted)} ${unit.symbol}"
    }
}

/**
 * Personal Record & Epley 1RM Engine.
 * Estimated 1RM = Weight * (1 + Reps / 30.0)
 * Restricted to strength resistance exercises with valid rep ranges (1..15) so high-rep endurance
 * sets or cardio exercises do not produce misleading 1RM estimates.
 */
object PrCalculator {
    const val MAX_VALID_EPLEY_REPS = 15

    fun calculateEstimated1RmKg(
        weightKg: Double,
        reps: Int,
        isStrengthExercise: Boolean = true
    ): Double? {
        if (!isStrengthExercise || weightKg <= 0.0 || reps <= 0 || reps > MAX_VALID_EPLEY_REPS) {
            return null
        }
        return if (reps == 1) {
            weightKg
        } else {
            weightKg * (1.0 + reps.toDouble() / 30.0)
        }
    }
}

enum class OverloadAction {
    INCREASE_WEIGHT,
    ADD_REPS,
    MAINTAIN_LOAD,
    FOCUS_CONSISTENCY
}

data class OverloadSuggestion(
    val exerciseId: String,
    val action: OverloadAction,
    val suggestedWeightKg: Double?,
    val suggestedReps: Int?,
    val headlineEn: String,
    val headlineHi: String,
    val rationaleEn: String,
    val rationaleHi: String
)

data class HistoricalSessionSnapshot(
    val performedAtEpochMillis: Long,
    val topWeightKg: Double,
    val repsAtTopWeight: Int,
    val completedSetsCount: Int,
    val totalVolumeKg: Double
)

/**
 * Progressive Overload Assistant based purely on recorded user performance.
 * Never automatically mutates user sets.
 */
object ProgressiveOverloadEngine {
    fun analyze(
        exerciseId: String,
        recentSessions: List<HistoricalSessionSnapshot>,
        targetRepsUpper: Int = 10,
        targetRepsLower: Int = 6
    ): OverloadSuggestion? {
        if (recentSessions.isEmpty()) return null
        val sorted = recentSessions.sortedByDescending { it.performedAtEpochMillis }
        val latest = sorted.first()

        if (latest.completedSetsCount < 2) {
            return OverloadSuggestion(
                exerciseId = exerciseId,
                action = OverloadAction.FOCUS_CONSISTENCY,
                suggestedWeightKg = latest.topWeightKg,
                suggestedReps = latest.repsAtTopWeight.coerceAtLeast(targetRepsLower),
                headlineEn = "Focus on Consistency",
                headlineHi = "निरंतरता पर ध्यान दें",
                rationaleEn = "Complete at least 3 working sets at this load before increasing weight.",
                rationaleHi = "वजन बढ़ाने से पहले इस भार पर कम से कम 3 वर्किंग सेट पूरे करें।"
            )
        }

        if (latest.repsAtTopWeight >= targetRepsUpper) {
            val incrementKg = if (latest.topWeightKg >= 40.0) 2.5 else 1.25
            val nextWeight = latest.topWeightKg + incrementKg
            return OverloadSuggestion(
                exerciseId = exerciseId,
                action = OverloadAction.INCREASE_WEIGHT,
                suggestedWeightKg = nextWeight,
                suggestedReps = targetRepsLower + 2,
                headlineEn = "Try Increasing Weight (+${incrementKg} kg)",
                headlineHi = "वजन बढ़ाने का प्रयास करें (+${incrementKg} kg)",
                rationaleEn = "You hit ${latest.repsAtTopWeight} reps at ${latest.topWeightKg} kg last session. Ready for a small progressive jump.",
                rationaleHi = "आपने पिछले सत्र में ${latest.topWeightKg} kg पर ${latest.repsAtTopWeight} रेप्स पूरे किए।"
            )
        }

        if (latest.repsAtTopWeight in targetRepsLower until targetRepsUpper) {
            val nextReps = latest.repsAtTopWeight + 1
            return OverloadSuggestion(
                exerciseId = exerciseId,
                action = OverloadAction.ADD_REPS,
                suggestedWeightKg = latest.topWeightKg,
                suggestedReps = nextReps,
                headlineEn = "Complete +1 Additional Repetition",
                headlineHi = "+1 अतिरिक्त रेप पूरा करें",
                rationaleEn = "Keep weight at ${latest.topWeightKg} kg and aim for $nextReps clean reps to build volume.",
                rationaleHi = "वजन ${latest.topWeightKg} kg रखें और $nextReps रेप्स का लक्ष्य रखें।"
            )
        }

        return OverloadSuggestion(
            exerciseId = exerciseId,
            action = OverloadAction.MAINTAIN_LOAD,
            suggestedWeightKg = latest.topWeightKg,
            suggestedReps = targetRepsLower,
            headlineEn = "Maintain Current Load",
            headlineHi = "वर्तमान भार बनाए रखें",
            rationaleEn = "Stabilize technique at ${latest.topWeightKg} kg until you comfortably reach $targetRepsLower reps.",
            rationaleHi = "जब तक आप आराम से $targetRepsLower रेप्स तक न पहुँचें, वर्तमान भार बनाए रखें।"
        )
    }
}

data class PlateLoadResult(
    val targetWeight: Double,
    val barWeight: Double,
    val achievableWeight: Double,
    val perSidePlates: List<Pair<Double, Int>>,
    val remainderUnloaded: Double,
    val isValid: Boolean = true,
    val errorMessage: String? = null
)

/**
 * Barbell Plate Calculator supporting both Metric (kg) and Imperial (lbs) denominations.
 */
object PlateCalculator {
    val DEFAULT_PLATES_KG = listOf(25.0, 20.0, 15.0, 10.0, 5.0, 2.5, 1.25)
    val DEFAULT_PLATES_LBS = listOf(45.0, 35.0, 25.0, 10.0, 5.0, 2.5)

    fun calculatePerSide(
        targetWeight: Double,
        barWeight: Double,
        availableDenominations: List<Double> = DEFAULT_PLATES_KG
    ): PlateLoadResult {
        if (!targetWeight.isFinite() || !barWeight.isFinite() || targetWeight < 0.0 || barWeight < 0.0) {
            return PlateLoadResult(targetWeight, barWeight, 0.0, emptyList(), 0.0, false, "Enter valid positive weights.")
        }
        if (targetWeight < barWeight) {
            return PlateLoadResult(targetWeight, barWeight, barWeight, emptyList(), barWeight - targetWeight, false, "Target weight cannot be lower than the bar weight.")
        }
        val sortedPlates = availableDenominations.filter { it.isFinite() && it > 0.0 }.distinct().sortedDescending()
        if (targetWeight > barWeight && sortedPlates.isEmpty()) {
            return PlateLoadResult(targetWeight, barWeight, barWeight, emptyList(), targetWeight - barWeight, false, "No valid plate sizes are available.")
        }
        if (targetWeight == barWeight) {
            return PlateLoadResult(targetWeight, barWeight, barWeight, emptyList(), 0.0)
        }
        var remainingPerSide = (targetWeight - barWeight) / 2.0
        val loaded = mutableListOf<Pair<Double, Int>>()

        for (plate in sortedPlates) {
            val count = floor((remainingPerSide + 1e-6) / plate).toInt()
            if (count > 0) {
                loaded.add(plate to count)
                remainingPerSide -= count * plate
            }
        }
        val totalLoadedPlatesWeight = loaded.sumOf { (plate, count) -> plate * count * 2.0 }
        val achievable = barWeight + totalLoadedPlatesWeight
        return PlateLoadResult(
            targetWeight = targetWeight,
            barWeight = barWeight,
            achievableWeight = achievable,
            perSidePlates = loaded,
            remainderUnloaded = (targetWeight - achievable).coerceAtLeast(0.0)
        )
    }
}

data class StreakSummary(
    val currentStreakDays: Int,
    val longestStreakDays: Int,
    val workoutsThisWeek: Int,
    val workoutsThisMonth: Int,
    val allowedRestGapDays: Int
)

/**
 * Streak & Activity Calculator.
 * Supports configurable rest-day grace periods (default maxRestDaysBetweenWorkouts = 2, meaning
 * lifting every 1 to 3 days keeps the active training streak alive without punishing healthy recovery).
 */
object StreakCalculator {
    fun calculateStreaks(
        workoutDates: Set<LocalDate>,
        today: LocalDate = LocalDate.now(),
        maxRestDaysBetweenWorkouts: Int = 2
    ): StreakSummary {
        if (workoutDates.isEmpty()) {
            return StreakSummary(0, 0, 0, 0, maxRestDaysBetweenWorkouts)
        }
        val sortedAsc = workoutDates.sorted()
        val maxAllowedDayDiff = maxRestDaysBetweenWorkouts + 1L

        var longestSessionsStreak = 1
        var runningStreak = 1

        for (i in 1 until sortedAsc.size) {
            val gap = ChronoUnit.DAYS.between(sortedAsc[i - 1], sortedAsc[i])
            if (gap in 1..maxAllowedDayDiff) {
                runningStreak += 1
                if (runningStreak > longestSessionsStreak) {
                    longestSessionsStreak = runningStreak
                }
            } else if (gap > maxAllowedDayDiff) {
                runningStreak = 1
            }
        }

        val lastWorkoutDate = sortedAsc.last()
        val daysSinceLastWorkout = ChronoUnit.DAYS.between(lastWorkoutDate, today)
        val currentStreak = if (daysSinceLastWorkout <= maxRestDaysBetweenWorkouts) {
            runningStreak
        } else {
            0
        }

        val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
        val workoutsThisWeek = workoutDates.count { !it.isBefore(weekStart) && !it.isAfter(today) }
        val workoutsThisMonth = workoutDates.count { it.year == today.year && it.month == today.month }

        return StreakSummary(
            currentStreakDays = currentStreak,
            longestStreakDays = longestSessionsStreak,
            workoutsThisWeek = workoutsThisWeek,
            workoutsThisMonth = workoutsThisMonth,
            allowedRestGapDays = maxRestDaysBetweenWorkouts
        )
    }
}

/**
 * Background-safe timestamp-based Rest Timer state calculator.
 * Never relies on naive delay ticks alone; computes remaining time from targetEpochMillis.
 */
data class RestTimerState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val totalDurationSeconds: Int = 90,
    val targetEndEpochMillis: Long? = null,
    val pausedRemainingMillis: Long = 90_000L
) {
    fun remainingSeconds(nowEpochMillis: Long = System.currentTimeMillis()): Int {
        return when {
            isRunning && targetEndEpochMillis != null -> {
                val diff = (targetEndEpochMillis - nowEpochMillis).coerceAtLeast(0L)
                ((diff + 999L) / 1000L).toInt()
            }
            isPaused -> ((pausedRemainingMillis + 999L) / 1000L).toInt()
            else -> totalDurationSeconds
        }
    }

    fun isFinished(nowEpochMillis: Long = System.currentTimeMillis()): Boolean {
        return isRunning && targetEndEpochMillis != null && nowEpochMillis >= targetEndEpochMillis
    }

    companion object {
        val PRESET_DURATIONS_SECONDS = listOf(30, 60, 90, 120, 180)

        fun start(durationSeconds: Int, nowEpochMillis: Long = System.currentTimeMillis()): RestTimerState {
            val cleanSeconds = durationSeconds.coerceIn(5, 3600)
            return RestTimerState(
                isRunning = true,
                isPaused = false,
                totalDurationSeconds = cleanSeconds,
                targetEndEpochMillis = nowEpochMillis + cleanSeconds * 1000L,
                pausedRemainingMillis = cleanSeconds * 1000L
            )
        }

        fun pause(current: RestTimerState, nowEpochMillis: Long = System.currentTimeMillis()): RestTimerState {
            if (!current.isRunning || current.targetEndEpochMillis == null) return current
            val remaining = (current.targetEndEpochMillis - nowEpochMillis).coerceAtLeast(0L)
            return current.copy(
                isRunning = false,
                isPaused = true,
                targetEndEpochMillis = null,
                pausedRemainingMillis = remaining
            )
        }

        fun resume(current: RestTimerState, nowEpochMillis: Long = System.currentTimeMillis()): RestTimerState {
            if (!current.isPaused) return current
            return current.copy(
                isRunning = true,
                isPaused = false,
                targetEndEpochMillis = nowEpochMillis + current.pausedRemainingMillis
            )
        }

        fun adjustSeconds(
            current: RestTimerState,
            deltaSeconds: Int,
            nowEpochMillis: Long = System.currentTimeMillis()
        ): RestTimerState {
            val deltaMillis = deltaSeconds * 1000L
            return when {
                current.isRunning && current.targetEndEpochMillis != null -> {
                    val newTarget = (current.targetEndEpochMillis + deltaMillis).coerceAtLeast(nowEpochMillis)
                    val newTotal = (current.totalDurationSeconds + deltaSeconds).coerceAtLeast(5)
                    current.copy(targetEndEpochMillis = newTarget, totalDurationSeconds = newTotal)
                }
                current.isPaused -> {
                    val newPaused = (current.pausedRemainingMillis + deltaMillis).coerceAtLeast(0L)
                    val newTotal = (current.totalDurationSeconds + deltaSeconds).coerceAtLeast(5)
                    current.copy(pausedRemainingMillis = newPaused, totalDurationSeconds = newTotal)
                }
                else -> {
                    val newTotal = (current.totalDurationSeconds + deltaSeconds).coerceIn(5, 3600)
                    current.copy(totalDurationSeconds = newTotal, pausedRemainingMillis = newTotal * 1000L)
                }
            }
        }
    }
}
