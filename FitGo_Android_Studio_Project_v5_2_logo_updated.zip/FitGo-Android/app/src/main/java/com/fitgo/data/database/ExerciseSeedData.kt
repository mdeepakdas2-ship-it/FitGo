package com.fitgo.data.database

import com.fitgo.data.database.entities.ExerciseCategory
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.ExerciseType
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity

object ExerciseSeedData {
    val starterExercises: List<ExerciseEntity> = listOf(
        ExerciseEntity(
            id = "ex_bench_press",
            name = "Barbell Bench Press",
            nameHi = "बारबेल बेंच प्रेस",
            category = ExerciseCategory.CHEST,
            primaryMuscle = "Pectoralis Major",
            secondaryMusclesCsv = "Anterior Deltoids, Triceps Brachii",
            equipment = "Barbell, Flat Bench",
            instructions = "Retract shoulder blades, lower bar to mid-chest with controlled tempo, press to lockout.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "chest_barbell"
        ),
        ExerciseEntity(
            id = "ex_incline_db_press",
            name = "Incline Dumbbell Press",
            nameHi = "इंक्लाइन डंबल प्रेस",
            category = ExerciseCategory.CHEST,
            primaryMuscle = "Clavicular Pectoralis",
            secondaryMusclesCsv = "Anterior Deltoids, Triceps",
            equipment = "Dumbbells, Incline Bench (30°)",
            instructions = "Press dumbbells upward on a 30-degree incline while maintaining scapular stability.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "chest_dumbbell"
        ),
        ExerciseEntity(
            id = "ex_deadlift",
            name = "Conventional Barbell Deadlift",
            nameHi = "बारबेल डेडलिफ्ट",
            category = ExerciseCategory.BACK,
            primaryMuscle = "Erector Spinae, Latissimus Dorsi",
            secondaryMusclesCsv = "Glutes, Hamstrings, Traps, Forearms",
            equipment = "Barbell",
            instructions = "Brace core with neutral spine, push floor away through mid-foot, lock hips and knees together.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "back_barbell"
        ),
        ExerciseEntity(
            id = "ex_pull_up",
            name = "Weighted / Bodyweight Pull-Up",
            nameHi = "पुल-अप",
            category = ExerciseCategory.BACK,
            primaryMuscle = "Latissimus Dorsi",
            secondaryMusclesCsv = "Biceps, Rhomboids, Rear Deltoids",
            equipment = "Pull-Up Bar",
            instructions = "Pull chest toward bar by driving elbows down to ribs; control the eccentric descent.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "back_pullup"
        ),
        ExerciseEntity(
            id = "ex_ohp",
            name = "Overhead Barbell Press",
            nameHi = "ओवरहेड बारबेल प्रेस",
            category = ExerciseCategory.SHOULDERS,
            primaryMuscle = "Anterior & Lateral Deltoids",
            secondaryMusclesCsv = "Triceps, Upper Chest, Core",
            equipment = "Barbell",
            instructions = "Squeeze glutes and abs, press bar vertically from clavicle to overhead lockout.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "shoulders_barbell"
        ),
        ExerciseEntity(
            id = "ex_lateral_raise",
            name = "Dumbbell Lateral Raise",
            nameHi = "डंबल लेटरल रेज़",
            category = ExerciseCategory.SHOULDERS,
            primaryMuscle = "Lateral Deltoid",
            secondaryMusclesCsv = "Supraspinatus, Upper Traps",
            equipment = "Dumbbells",
            instructions = "Raise arms out to the sides with slight elbow bend until parallel to the floor.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "shoulders_dumbbell"
        ),
        ExerciseEntity(
            id = "ex_barbell_curl",
            name = "EZ-Bar / Barbell Bicep Curl",
            nameHi = "बारबेल बाइसेप कर्ल",
            category = ExerciseCategory.BICEPS,
            primaryMuscle = "Biceps Brachii",
            secondaryMusclesCsv = "Brachialis, Forearms",
            equipment = "Barbell / EZ-Bar",
            instructions = "Keep elbows pinned to sides, curl weight to full contraction without torso swing.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "biceps_curl"
        ),
        ExerciseEntity(
            id = "ex_tricep_pushdown",
            name = "Cable Tricep Rope Pushdown",
            nameHi = "केबल ट्राइसेप पुशडाउन",
            category = ExerciseCategory.TRICEPS,
            primaryMuscle = "Triceps Brachii (Lateral & Medial Heads)",
            secondaryMusclesCsv = "Anconeus",
            equipment = "Cable Machine, Rope Attachment",
            instructions = "Keep upper arms stationary, extend elbows fully and spread the rope at the bottom.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "triceps_cable"
        ),
        ExerciseEntity(
            id = "ex_barbell_squat",
            name = "Barbell Back Squat",
            nameHi = "बारबेल बैक स्क्वाट",
            category = ExerciseCategory.LEGS,
            primaryMuscle = "Quadriceps Femoris",
            secondaryMusclesCsv = "Gluteus Maximus, Adductors, Core",
            equipment = "Barbell, Squat Rack",
            instructions = "Brace torso, descend until hips crease below knees, drive forcefully back to standing.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "legs_squat"
        ),
        ExerciseEntity(
            id = "ex_hip_thrust",
            name = "Barbell Hip Thrust",
            nameHi = "बारबेल हिप थ्रस्ट",
            category = ExerciseCategory.GLUTES,
            primaryMuscle = "Gluteus Maximus",
            secondaryMusclesCsv = "Hamstrings, Core",
            equipment = "Barbell, Bench",
            instructions = "Rest upper back on bench, drive through heels to full hip extension with chin tucked.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "glutes_hipthrust"
        ),
        ExerciseEntity(
            id = "ex_hanging_leg_raise",
            name = "Hanging Leg Raise",
            nameHi = "हैंगिंग लेग रेज़",
            category = ExerciseCategory.ABS,
            primaryMuscle = "Rectus Abdominis",
            secondaryMusclesCsv = "Hip Flexors, Obliques, Grip",
            equipment = "Pull-Up Bar",
            instructions = "Posteriorly tilt pelvis to curl legs upward without momentum; lower slowly.",
            exerciseType = ExerciseType.BODYWEIGHT_REPS,
            illustrationKey = "abs_core"
        ),
        ExerciseEntity(
            id = "ex_farmers_walk",
            name = "Heavy Farmer's Carry",
            nameHi = "फ़ार्मर्स वॉक",
            category = ExerciseCategory.FOREARMS,
            primaryMuscle = "Forearm Flexors, Grip",
            secondaryMusclesCsv = "Traps, Core, Calves",
            equipment = "Heavy Dumbbells / Trap Bar",
            instructions = "Stand tall with shoulders packed and walk briskly for target distance or duration.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "forearms_carry"
        ),
        ExerciseEntity(
            id = "ex_rowing_erg",
            name = "Indoor Rowing Intervals",
            nameHi = "इनडोर रोइंग कार्डियो",
            category = ExerciseCategory.CARDIO,
            primaryMuscle = "Cardiovascular System",
            secondaryMusclesCsv = "Legs, Lats, Core",
            equipment = "Rowing Ergometer",
            instructions = "Drive with legs first, hinge back, pull handle to lower ribs, and recover smoothly.",
            exerciseType = ExerciseType.DISTANCE_AND_DURATION,
            illustrationKey = "cardio_rower"
        ),
        ExerciseEntity(
            id = "ex_kettlebell_clean_press",
            name = "Kettlebell Clean & Press",
            nameHi = "केटलबेल क्लीन एंड प्रेस",
            category = ExerciseCategory.FULL_BODY,
            primaryMuscle = "Full Body Kinetic Chain",
            secondaryMusclesCsv = "Glutes, Hamstrings, Shoulders, Core",
            equipment = "Kettlebell",
            instructions = "Hinge hips to clean kettlebell cleanly to rack position, then press overhead.",
            exerciseType = ExerciseType.WEIGHT_AND_REPS,
            illustrationKey = "fullbody_kb"
        )
    )

    val starterRoutines: List<RoutineEntity> = listOf(
        RoutineEntity(
            id = "routine_sample_upper",
            name = "Sample: Upper Body Foundation",
            description = "Beginner-friendly compound upper body strength routine (Sample Routine).",
            isSampleRoutine = true
        ),
        RoutineEntity(
            id = "routine_sample_lower",
            name = "Sample: Lower Body & Core Power",
            description = "Squat, hinge, glute, and abdominal stability session (Sample Routine).",
            isSampleRoutine = true
        ),
        RoutineEntity(
            id = "routine_sample_fullbody",
            name = "Sample: Full Body 3x/Week Express",
            description = "Balanced full-body workout for lifters training 3 days per week (Sample Routine).",
            isSampleRoutine = true
        )
    )

    val starterRoutineExercises: List<RoutineExerciseEntity> = listOf(
        RoutineExerciseEntity("re_1", "routine_sample_upper", "ex_bench_press", 0, 3, 8, 120),
        RoutineExerciseEntity("re_2", "routine_sample_upper", "ex_pull_up", 1, 3, 8, 120),
        RoutineExerciseEntity("re_3", "routine_sample_upper", "ex_ohp", 2, 3, 10, 90),
        RoutineExerciseEntity("re_4", "routine_sample_upper", "ex_barbell_curl", 3, 3, 12, 60, supersetGroupId = "SS_ARM"),
        RoutineExerciseEntity("re_5", "routine_sample_upper", "ex_tricep_pushdown", 4, 3, 12, 60, supersetGroupId = "SS_ARM"),
        RoutineExerciseEntity("re_6", "routine_sample_lower", "ex_barbell_squat", 0, 4, 6, 150),
        RoutineExerciseEntity("re_7", "routine_sample_lower", "ex_deadlift", 1, 3, 5, 180),
        RoutineExerciseEntity("re_8", "routine_sample_lower", "ex_hip_thrust", 2, 3, 10, 90),
        RoutineExerciseEntity("re_9", "routine_sample_lower", "ex_hanging_leg_raise", 3, 3, 12, 60),
        RoutineExerciseEntity("re_10", "routine_sample_fullbody", "ex_barbell_squat", 0, 3, 8, 120),
        RoutineExerciseEntity("re_11", "routine_sample_fullbody", "ex_bench_press", 1, 3, 8, 120),
        RoutineExerciseEntity("re_12", "routine_sample_fullbody", "ex_pull_up", 2, 3, 8, 90),
        RoutineExerciseEntity("re_13", "routine_sample_fullbody", "ex_kettlebell_clean_press", 3, 3, 10, 90)
    )
}
