package com.fitgo.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.fitgo.data.database.entities.BodyMeasurementEntity
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutExerciseEntity
import com.fitgo.data.database.entities.WorkoutSetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FitGoDao {

    // EXERCISES
    @Query("SELECT * FROM exercises WHERE isArchived = 0 ORDER BY name ASC")
    fun observeActiveExercises(): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises")
    suspend fun getAllExercisesOnce(): List<ExerciseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExercises(exercises: List<ExerciseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExercise(exercise: ExerciseEntity)

    @Query("UPDATE exercises SET isFavourite = :isFav WHERE id = :exerciseId")
    suspend fun setExerciseFavourite(exerciseId: String, isFav: Boolean)

    @Query("UPDATE exercises SET isArchived = 1 WHERE id = :exerciseId AND isCustom = 1")
    suspend fun archiveCustomExercise(exerciseId: String)

    // WORKOUTS & AUTOSAVE RECOVERY
    @Query("SELECT * FROM workouts WHERE isFinished = 0 ORDER BY startedAtEpochMillis DESC LIMIT 1")
    fun observeUnfinishedWorkout(): Flow<WorkoutEntity?>

    @Query("SELECT * FROM workouts WHERE isFinished = 0 ORDER BY startedAtEpochMillis DESC LIMIT 1")
    suspend fun getUnfinishedWorkoutOnce(): WorkoutEntity?

    @Query("SELECT * FROM workouts WHERE isFinished = 1 ORDER BY startedAtEpochMillis DESC")
    fun observeFinishedWorkouts(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts")
    suspend fun getAllWorkoutsOnce(): List<WorkoutEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkout(workout: WorkoutEntity)

    @Query("DELETE FROM workouts WHERE id = :workoutId")
    suspend fun deleteWorkoutById(workoutId: String)

    // WORKOUT EXERCISES & SETS
    @Query("SELECT * FROM workout_exercises WHERE workoutId = :workoutId ORDER BY orderIndex ASC")
    fun observeWorkoutExercises(workoutId: String): Flow<List<WorkoutExerciseEntity>>

    @Query("SELECT * FROM workout_exercises WHERE workoutId = :workoutId ORDER BY orderIndex ASC")
    suspend fun getWorkoutExercisesOnce(workoutId: String): List<WorkoutExerciseEntity>

    @Query("SELECT * FROM workout_exercises")
    suspend fun getAllWorkoutExercisesOnce(): List<WorkoutExerciseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkoutExercise(workoutExercise: WorkoutExerciseEntity)

    @Query("UPDATE workout_exercises SET supersetGroupId = :groupId WHERE id IN (:exerciseIds)")
    suspend fun setSupersetGroup(exerciseIds: List<String>, groupId: String?)

    @Query("UPDATE workout_exercises SET supersetGroupId = NULL WHERE workoutId = :workoutId AND supersetGroupId = :groupId")
    suspend fun clearSupersetGroup(workoutId: String, groupId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkoutExercises(items: List<WorkoutExerciseEntity>)

    @Query("DELETE FROM workout_exercises WHERE id = :workoutExerciseId")
    suspend fun deleteWorkoutExercise(workoutExerciseId: String)

    @Query("SELECT * FROM workout_sets WHERE workoutId = :workoutId ORDER BY setOrder ASC")
    fun observeWorkoutSets(workoutId: String): Flow<List<WorkoutSetEntity>>

    @Query("SELECT * FROM workout_sets WHERE workoutId = :workoutId ORDER BY setOrder ASC")
    suspend fun getWorkoutSetsOnce(workoutId: String): List<WorkoutSetEntity>

    @Query("SELECT * FROM workout_sets")
    suspend fun getAllWorkoutSetsOnce(): List<WorkoutSetEntity>

    @Query("""
        SELECT ws.* FROM workout_sets ws
        INNER JOIN workouts w ON ws.workoutId = w.id
        WHERE ws.exerciseId = :exerciseId AND w.isFinished = 1 AND ws.isCompleted = 1
        ORDER BY w.startedAtEpochMillis DESC, ws.setOrder ASC
        LIMIT 30
    """)
    suspend fun getRecentCompletedSetsForExercise(exerciseId: String): List<WorkoutSetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkoutSet(workoutSet: WorkoutSetEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkoutSets(sets: List<WorkoutSetEntity>)

    @Query("DELETE FROM workout_sets WHERE id = :setId")
    suspend fun deleteWorkoutSetById(setId: String)

    // PERSONAL RECORDS
    @Query("SELECT * FROM personal_records ORDER BY achievedAtEpochMillis DESC")
    fun observeAllPersonalRecords(): Flow<List<PersonalRecordEntity>>

    @Query("SELECT * FROM personal_records")
    suspend fun getAllPersonalRecordsOnce(): List<PersonalRecordEntity>

    @Query("SELECT * FROM personal_records WHERE exerciseId = :exerciseId ORDER BY maxWeightKg DESC LIMIT 1")
    suspend fun getBestRecordForExercise(exerciseId: String): PersonalRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPersonalRecord(record: PersonalRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPersonalRecords(records: List<PersonalRecordEntity>)

    // ROUTINES
    @Query("SELECT * FROM routines ORDER BY isSampleRoutine ASC, createdAtEpochMillis DESC")
    fun observeRoutines(): Flow<List<RoutineEntity>>

    @Query("SELECT * FROM routines")
    suspend fun getAllRoutinesOnce(): List<RoutineEntity>

    @Query("SELECT * FROM routine_exercises WHERE routineId = :routineId ORDER BY orderIndex ASC")
    suspend fun getRoutineExercisesOnce(routineId: String): List<RoutineExerciseEntity>

    @Query("SELECT * FROM routine_exercises")
    suspend fun getAllRoutineExercisesOnce(): List<RoutineExerciseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRoutine(routine: RoutineEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRoutines(routines: List<RoutineEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRoutineExercises(exercises: List<RoutineExerciseEntity>)

    @Query("DELETE FROM routine_exercises WHERE routineId = :routineId")
    suspend fun clearRoutineExercises(routineId: String)

    @Transaction
    suspend fun replaceRoutineWithExercises(routine: RoutineEntity, exercises: List<RoutineExerciseEntity>) {
        upsertRoutine(routine)
        clearRoutineExercises(routine.id)
        if (exercises.isNotEmpty()) upsertRoutineExercises(exercises)
    }

    @Query("DELETE FROM routines WHERE id = :routineId")
    suspend fun deleteRoutineById(routineId: String)

    // BODY MEASUREMENTS
    @Query("SELECT * FROM body_measurements ORDER BY recordedAtEpochMillis DESC")
    fun observeBodyMeasurements(): Flow<List<BodyMeasurementEntity>>

    @Query("SELECT * FROM body_measurements ORDER BY recordedAtEpochMillis DESC")
    suspend fun getAllBodyMeasurementsOnce(): List<BodyMeasurementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBodyMeasurement(measurement: BodyMeasurementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBodyMeasurements(measurements: List<BodyMeasurementEntity>)

    @Query("DELETE FROM body_measurements WHERE id = :id")
    suspend fun deleteBodyMeasurementById(id: String)

    // TRANSACTIONAL FULL RESTORE & CLEAR
    @Query("DELETE FROM workout_sets")
    suspend fun clearAllWorkoutSets()

    @Query("DELETE FROM workout_exercises")
    suspend fun clearAllWorkoutExercises()

    @Query("DELETE FROM workouts")
    suspend fun clearAllWorkouts()

    @Query("DELETE FROM personal_records")
    suspend fun clearAllPersonalRecords()

    @Query("DELETE FROM routine_exercises")
    suspend fun clearAllRoutineExercises()

    @Query("DELETE FROM routines")
    suspend fun clearAllRoutines()

    @Query("DELETE FROM body_measurements")
    suspend fun clearAllBodyMeasurements()

    @Query("DELETE FROM exercises")
    suspend fun clearAllExercises()

    @Transaction
    suspend fun replaceEntireDatabaseTransactionally(
        exercises: List<ExerciseEntity>,
        workouts: List<WorkoutEntity>,
        workoutExercises: List<WorkoutExerciseEntity>,
        workoutSets: List<WorkoutSetEntity>,
        personalRecords: List<PersonalRecordEntity>,
        routines: List<RoutineEntity>,
        routineExercises: List<RoutineExerciseEntity>,
        bodyMeasurements: List<BodyMeasurementEntity>
    ) {
        clearAllWorkoutSets()
        clearAllWorkoutExercises()
        clearAllWorkouts()
        clearAllPersonalRecords()
        clearAllRoutineExercises()
        clearAllRoutines()
        clearAllBodyMeasurements()
        clearAllExercises()

        upsertExercises(exercises)
        upsertWorkoutsBatch(workouts)
        upsertWorkoutExercises(workoutExercises)
        upsertWorkoutSets(workoutSets)
        upsertPersonalRecords(personalRecords)
        upsertRoutines(routines)
        upsertRoutineExercises(routineExercises)
        upsertBodyMeasurements(bodyMeasurements)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkoutsBatch(workouts: List<WorkoutEntity>)
}
