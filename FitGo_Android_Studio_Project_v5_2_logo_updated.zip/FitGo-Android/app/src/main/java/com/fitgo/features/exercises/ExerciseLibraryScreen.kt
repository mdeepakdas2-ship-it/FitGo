package com.fitgo.features.exercises

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.FitGoCard
import com.fitgo.data.database.entities.ExerciseCategory

@Composable
fun CustomExerciseCreatorCard(
    onCreateExercise: (String, ExerciseCategory, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var primaryMuscle by remember { mutableStateOf("") }
    var equipment by remember { mutableStateOf("Barbell") }
    var instructions by remember { mutableStateOf("") }

    FitGoCard {
        Text("Create Custom Exercise", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Exercise Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = primaryMuscle,
                onValueChange = { primaryMuscle = it },
                label = { Text("Primary Muscle") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = equipment,
                onValueChange = { equipment = it },
                label = { Text("Equipment") },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = instructions,
            onValueChange = { instructions = it },
            label = { Text("Coaching Instructions") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                if (name.isNotBlank()) {
                    onCreateExercise(name, ExerciseCategory.FULL_BODY, primaryMuscle, equipment, instructions)
                    name = ""
                    primaryMuscle = ""
                    instructions = ""
                }
            },
            enabled = name.isNotBlank()
        ) {
            Text("Save Custom Exercise")
        }
    }
}
