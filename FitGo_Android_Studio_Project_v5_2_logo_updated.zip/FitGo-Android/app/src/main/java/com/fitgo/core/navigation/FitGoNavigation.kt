package com.fitgo.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class PrimaryTab(
    val route: String,
    val titleEn: String,
    val titleHi: String,
    val icon: ImageVector
) {
    HOME("home", "Home", "होम", Icons.Default.Home),
    WORKOUT("workout", "Workout", "वर्कआउट", Icons.Default.FitnessCenter),
    HISTORY("history", "History", "इतिहास", Icons.Default.History),
    ANALYTICS("analytics", "Analytics", "विश्लेषण", Icons.Default.Analytics),
    SETTINGS("settings", "Settings", "सेटिंग्स", Icons.Default.Settings)
}
