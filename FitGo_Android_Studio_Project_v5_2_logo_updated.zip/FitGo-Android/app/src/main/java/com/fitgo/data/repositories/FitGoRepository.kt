package com.fitgo.data.repositories

import com.fitgo.core.utils.HistoricalSessionSnapshot
import com.fitgo.core.utils.PrCalculator
import com.fitgo.core.utils.ProgressiveOverloadEngine
import com.fitgo.core.utils.StreakCalculator
import com.fitgo.data.database.ExerciseSeedData
import com.fitgo.data.database.dao.FitGoDao
import com.fitgo.data.database.entities.BodyMeasurementEntity
import com.fitgo.data.database.entities.ExerciseCategory
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.ExerciseType
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.RoutineEntity
import com.fitgo.data.database.entities.RoutineExerciseEntity
import com.fitgo.data.database.entities.SetType
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutExerciseEntity
import com.fitgo.data.database.entities.WorkoutSetEntity
import com.fitgo.domain.models.ActiveWorkoutExerciseBlock
import com.fitgo.domain.models.CompletedWorkoutSummary
import com.fitgo.domain.models.DashboardMetrics
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FitGoRepository @Inject constructor(
    private val dao: FitGoDao
) {
    val activeExercisesFlow: Flow<List<ExerciseEntity>> = dao.observeActiveExercises()
    val finishedWorkoutsFlow: Flow<List<WorkoutEntity>> = dao.observeFinishedWorkouts()
    val unfinishedWorkoutFlow: Flow<WorkoutEntity?> = dao.observeUnfinishedWorkout()
    val personalRecordsFlow: Flow<List<PersonalRecordEntity>> = dao.observeAllPersonalRecords()
    val routinesFlow: Flow<List<RoutineEntity>> = dao.observeRoutines()
    val bodyMeasurementsFlow: Flow<List<BodyMeasurementEntity>> = dao.observeBodyMeasurements()

    suspend fun ensureSeedDataLoaded() {
        if (dao.getAllExercisesOnce().isEmpty()) {
            dao.upsertExercises(ExerciseSeedData.starterExercises)
        }
        if (dao.getAllRoutinesOnce().isEmpty()) {
            dao.upsertRoutines(ExerciseSeedData.starterRoutines)
            dao.upsertRoutineExercises(ExerciseSeedData.starterRoutineExercises)
        }
    }

    fun observeDashboardMetrics(maxRestDaysForStreak: Int = 2): Flow<DashboardMetrics> {
        return combine(
            finishedWorkoutsFlow,
            personalRecordsFlow,
            activeExercisesFlow
        ) { workouts, prs, exercises ->
            val zone = ZoneId.systemDefault()
            val workoutDates = workouts.map {
                Instant.ofEpochMilli(it.startedAtEpochMillis).atZone(zone).toLocalDate()
            }.toSet()

            val today = LocalDate.now(zone)
            val streak = StreakCalculator.calculateStreaks(
                workoutDates = workoutDates,
                today = today,
                maxRestDaysBetweenWorkouts = maxRestDaysForStreak
            )

            val last7Days = (6 downTo 0).map { offset ->
                val d = today.minusDays(offset.toLong())
                val dayLabel = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
                val dayVolume = workouts.filter {
                    Instant.ofEpochMilli(it.startedAtEpochMillis).atZone(zone).toLocalDate() == d
                }.sumOf { it.totalVolumeKg }
                dayLabel to dayVolume
            }

            DashboardMetrics(
                totalWorkouts = workouts.size,
                totalVolumeKg = workouts.sumOf { it.totalVolumeKg },
                totalPersonalRecords = prs.size,
                streakSummary = streak,
                recentWorkout = workouts.firstOrNull(),
                weeklyVolumeByDay = last7Days,
                muscleDistribution = exercises.groupingBy { it.category.displayNameEn }.eachCount()
            )
        }
    }

    suspend fun startNewWorkout(title: String, routineId: String? = null): WorkoutEntity {
        val existingUnfinished = dao.getUnfinishedWorkoutOnce()
        if (existingUnfinished != null) return existingUnfinished

        val now = System.currentTimeMillis()
        val workoutId = "wk_${UUID.randomUUID()}"
        val workout = WorkoutEntity(
            id = workoutId,
            title = title.ifBlank { "Strength Session" },
            routineId = routineId,
            startedAtEpochMillis = now,
            isFinished = false,
            lastAutosavedAtEpochMillis = now
        )
        dao.upsertWorkout(workout)

        if (routineId != null) {
            val routineItems = dao.getRoutineExercisesOnce(routineId)
            for (item in routineItems) {
                val weId = "we_${UUID.randomUUID()}"
                dao.upsertWorkoutExercise(
                    WorkoutExerciseEntity(
                        id = weId,
                        workoutId = workoutId,
                        exerciseId = item.exerciseId,
                        orderIndex = item.orderIndex,
                        notes = item.notes,
                        supersetGroupId = item.supersetGroupId
                    )
                )
                val prevSets = dao.getRecentCompletedSetsForExercise(item.exerciseId)
                val defaultWeight = prevSets.firstOrNull()?.weightKg ?: 20.0
                val setsToCreate = (1..item.targetSets).map { idx ->
                    WorkoutSetEntity(
                        id = "ws_${UUID.randomUUID()}",
                        workoutExerciseId = weId,
                        workoutId = workoutId,
                        exerciseId = item.exerciseId,
                        setOrder = idx,
                        setType = SetType.NORMAL,
                        weightKg = defaultWeight,
                        reps = item.targetReps,
                        isCompleted = false
                    )
                }
                dao.upsertWorkoutSets(setsToCreate)
            }
        }
        return workout
    }

    suspend fun addExerciseToWorkout(workoutId: String, exerciseId: String): WorkoutExerciseEntity {
        val current = dao.getWorkoutExercisesOnce(workoutId)
        val nextOrder = (current.maxOfOrNull { it.orderIndex } ?: -1) + 1
        val we = WorkoutExerciseEntity(
            id = "we_${UUID.randomUUID()}",
            workoutId = workoutId,
            exerciseId = exerciseId,
            orderIndex = nextOrder
        )
        dao.upsertWorkoutExercise(we)

        val prevSets = dao.getRecentCompletedSetsForExercise(exerciseId)
        val seedWeight = prevSets.firstOrNull()?.weightKg ?: 20.0
        val seedReps = prevSets.firstOrNull()?.reps ?: 10
        val initialSet = WorkoutSetEntity(
            id = "ws_${UUID.randomUUID()}",
            workoutExerciseId = we.id,
            workoutId = workoutId,
            exerciseId = exerciseId,
            setOrder = 1,
            setType = SetType.NORMAL,
            weightKg = seedWeight,
            reps = seedReps,
            isCompleted = false
        )
        dao.upsertWorkoutSet(initialSet)
        touchWorkoutAutosave(workoutId)
        return we
    }

    suspend fun createSupersetGroup(workoutId: String, firstExerciseId: String, secondExerciseId: String) {
        require(firstExerciseId != secondExerciseId) { "Choose two different exercises" }
        val current = dao.getWorkoutExercisesOnce(workoutId)
        val first = current.firstOrNull { it.id == firstExerciseId } ?: error("First exercise not found")
        val second = current.firstOrNull { it.id == secondExerciseId } ?: error("Second exercise not found")
        require(first.supersetGroupId == null && second.supersetGroupId == null) { "An exercise is already paired" }
        val groupId = "ss_${UUID.randomUUID()}"
        dao.setSupersetGroup(listOf(first.id, second.id), groupId)
    }

    suspend fun removeSupersetGroup(workoutId: String, groupId: String) {
        dao.clearSupersetGroup(workoutId, groupId)
    }

    suspend fun loadActiveExerciseBlocks(
        workoutId: String,
        includeOverload: Boolean
    ): List<ActiveWorkoutExerciseBlock> {
        val workoutExercises = dao.getWorkoutExercisesOnce(workoutId)
        val allSets = dao.getWorkoutSetsOnce(workoutId).groupBy { it.workoutExerciseId }
        val exercisesById = dao.getAllExercisesOnce().associateBy { it.id }

        return workoutExercises.mapNotNull { we ->
            val ex = exercisesById[we.exerciseId] ?: return@mapNotNull null
            val previousCompleted = dao.getRecentCompletedSetsForExercise(ex.id)
            val suggestion = if (includeOverload && previousCompleted.isNotEmpty()) {
                val groupedByWorkout = previousCompleted.groupBy { it.workoutId }.values.map { sList ->
                    val top = sList.maxByOrNull { it.weightKg } ?: sList.first()
                    HistoricalSessionSnapshot(
                        performedAtEpochMillis = top.completedAtEpochMillis ?: 0L,
                        topWeightKg = top.weightKg,
                        repsAtTopWeight = top.reps,
                        completedSetsCount = sList.size,
                        totalVolumeKg = sList.sumOf { it.weightKg * it.reps }
                    )
                }
                ProgressiveOverloadEngine.analyze(ex.id, groupedByWorkout)
            } else null

            ActiveWorkoutExerciseBlock(
                workoutExercise = we,
                exercise = ex,
                sets = allSets[we.id].orEmpty().sortedBy { it.setOrder },
                previousSessionSets = previousCompleted.take(5),
                overloadSuggestion = suggestion
            )
        }
    }

    suspend fun saveOrUpdateSet(set: WorkoutSetEntity) {
        dao.upsertWorkoutSet(set)
        touchWorkoutAutosave(set.workoutId)
    }

    suspend fun deleteSet(set: WorkoutSetEntity) {
        dao.deleteWorkoutSetById(set.id)
        touchWorkoutAutosave(set.workoutId)
    }

    private suspend fun touchWorkoutAutosave(workoutId: String) {
        val current = dao.getAllWorkoutsOnce().firstOrNull { it.id == workoutId } ?: return
        val sets = dao.getWorkoutSetsOnce(workoutId).filter { it.isCompleted }
        val volume = sets.sumOf { it.weightKg * it.reps }
        dao.upsertWorkout(
            current.copy(
                totalVolumeKg = volume,
                totalCompletedSets = sets.size,
                lastAutosavedAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun finishWorkoutSession(workoutId: String, notes: String): CompletedWorkoutSummary {
        val now = System.currentTimeMillis()
        val workouts = dao.getAllWorkoutsOnce()
        val current = workouts.first { it.id == workoutId }
        val exercisesById = dao.getAllExercisesOnce().associateBy { it.id }
        val workoutExercises = dao.getWorkoutExercisesOnce(workoutId)
        val completedSets = dao.getWorkoutSetsOnce(workoutId).filter { it.isCompleted }

        val totalVolume = completedSets.sumOf { it.weightKg * it.reps }
        val durationSec = ((now - current.startedAtEpochMillis) / 1000L).coerceAtLeast(1L)

        val newPrs = mutableListOf<PersonalRecordEntity>()
        val setsByExercise = completedSets.groupBy { it.exerciseId }

        for ((exerciseId, exSets) in setsByExercise) {
            val exercise = exercisesById[exerciseId]
            val isStrength = exercise?.exerciseType == ExerciseType.WEIGHT_AND_REPS
            val bestWeightSet = exSets.maxWithOrNull(compareBy<WorkoutSetEntity> { it.weightKg }.thenBy { it.reps })
                ?: continue
            val highestVolumeSet = exSets.maxByOrNull { it.weightKg * it.reps } ?: bestWeightSet
            val existingBest = dao.getBestRecordForExercise(exerciseId)

            val isNewRecord = existingBest == null ||
                bestWeightSet.weightKg > existingBest.maxWeightKg ||
                (bestWeightSet.weightKg == existingBest.maxWeightKg && bestWeightSet.reps > existingBest.maxRepsAtWeight)

            if (isNewRecord && bestWeightSet.weightKg > 0.0) {
                val est1Rm = PrCalculator.calculateEstimated1RmKg(
                    weightKg = bestWeightSet.weightKg,
                    reps = bestWeightSet.reps,
                    isStrengthExercise = isStrength
                )
                val pr = PersonalRecordEntity(
                    id = "pr_${UUID.randomUUID()}",
                    exerciseId = exerciseId,
                    workoutId = workoutId,
                    maxWeightKg = bestWeightSet.weightKg,
                    maxRepsAtWeight = bestWeightSet.reps,
                    estimatedOneRepMaxKg = est1Rm,
                    highestSetVolumeKg = highestVolumeSet.weightKg * highestVolumeSet.reps,
                    achievedAtEpochMillis = now
                )
                dao.upsertPersonalRecord(pr)
                newPrs.add(pr)
            }
            if (exercise != null) {
                dao.upsertExercise(exercise.copy(lastUsedEpochMillis = now))
            }
        }

        val finishedWorkout = current.copy(
            finishedAtEpochMillis = now,
            durationSeconds = durationSec,
            notes = notes.ifBlank { current.notes },
            totalVolumeKg = totalVolume,
            totalCompletedSets = completedSets.size,
            prCountAchieved = newPrs.size,
            isFinished = true,
            lastAutosavedAtEpochMillis = now
        )
        dao.upsertWorkout(finishedWorkout)

        val previousFinished = workouts
            .filter { it.isFinished && it.id != workoutId }
            .maxByOrNull { it.startedAtEpochMillis }
        val volumeDelta = previousFinished?.let { totalVolume - it.totalVolumeKg }

        return CompletedWorkoutSummary(
            workout = finishedWorkout,
            exerciseCount = workoutExercises.size,
            completedSetsCount = completedSets.size,
            totalVolumeKg = totalVolume,
            achievedPrs = newPrs,
            previousVolumeDeltaKg = volumeDelta
        )
    }

    suspend fun cancelActiveWorkout(workoutId: String) {
        dao.deleteWorkoutById(workoutId)
    }

    suspend fun saveCustomExercise(
        id: String?,
        name: String,
        category: ExerciseCategory,
        primaryMuscle: String,
        secondaryMuscles: String,
        equipment: String,
        instructions: String,
        exerciseType: ExerciseType
    ) {
        val entity = ExerciseEntity(
            id = id ?: "ex_custom_${UUID.randomUUID()}",
            name = name.trim(),
            category = category,
            primaryMuscle = primaryMuscle.trim(),
            secondaryMusclesCsv = secondaryMuscles.trim(),
            equipment = equipment.trim(),
            instructions = instructions.trim(),
            exerciseType = exerciseType,
            isCustom = true
        )
        dao.upsertExercise(entity)
    }

    suspend fun toggleFavouriteExercise(exerciseId: String, currentFav: Boolean) {
        dao.setExerciseFavourite(exerciseId, !currentFav)
    }

    suspend fun archiveCustomExercise(exerciseId: String) {
        dao.archiveCustomExercise(exerciseId)
    }

    suspend fun saveRoutine(
        id: String?,
        name: String,
        description: String,
        exercises: List<RoutineExerciseEntity>
    ) {
        val routineId = id ?: "rt_${UUID.randomUUID()}"
        val routine = RoutineEntity(
            id = routineId,
            name = name.trim(),
            description = description.trim(),
            isSampleRoutine = false
        )
        val safeExercises = exercises.distinctBy { it.exerciseId }.mapIndexed { index, item ->
            item.copy(id = "re_${UUID.randomUUID()}", routineId = routineId, orderIndex = index)
        }
        require(name.isNotBlank()) { "Routine name is required" }
        require(safeExercises.isNotEmpty()) { "Select at least one exercise" }
        dao.replaceRoutineWithExercises(routine, safeExercises)
    }

    suspend fun saveBodyMeasurement(measurement: BodyMeasurementEntity) {
        dao.upsertBodyMeasurement(measurement)
    }

    suspend fun deleteBodyMeasurement(id: String) {
        dao.deleteBodyMeasurementById(id)
    }

    suspend fun deleteRoutine(id: String) {
        val routine = dao.getAllRoutinesOnce().firstOrNull { it.id == id } ?: return
        if (!routine.isSampleRoutine) dao.deleteRoutineById(id)
    }
}
