package com.fitgo

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FitGoApplication : Application()
