package com.fitgo.features.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.AccessibleStatusBadge
import com.fitgo.core.design.FitGoBarChart
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.utils.UnitConverter
import com.fitgo.features.FitGoMainViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun HomeDashboardScreen(
    viewModel: FitGoMainViewModel,
    onNavigateToWorkout: () -> Unit
) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val unfinished by viewModel.unfinishedWorkout.collectAsState()
    val routines by viewModel.routines.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val isHindi = settings.languageCode == "hi"

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isHindi) "नमस्ते, एथलीट" else "Welcome back, Athlete",
                        style = MaterialTheme.typography.headlineLarge
                    )
                    Text(
                        text = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")),
                        style = MaterialTheme.typography.bodyMedium,
                        color = LocalFitGoColors.current.onSurfaceVariant
                    )
                }
                AccessibleStatusBadge(label = if (isHindi) "100% ऑफ़लाइन" else "100% Offline", isSuccess = true)
            }
        }

        item {
            FitGoCard {
                Text(
                    text = if (unfinished != null) {
                        if (isHindi) "अधूरा वर्कआउट सत्र मिला" else "Unfinished Workout Recovered"
                    } else {
                        if (isHindi) "आज का प्रशिक्षण" else "Today's Training Status"
                    },
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = unfinished?.title ?: if (isHindi) "अपना अगला वर्कआउट लॉग करने के लिए तैयार।" else "Ready to log your next strength session.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (unfinished == null) viewModel.startWorkout()
                        onNavigateToWorkout()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (unfinished != null) {
                            if (isHindi) "वर्कआउट जारी रखें" else "Resume Active Workout"
                        } else {
                            if (isHindi) "वर्कआउट शुरू करें" else "Start Empty Workout"
                        }
                    )
                }
            }
        }

        item {
            val m = metrics
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FitGoCard(modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = LocalFitGoColors.current.primary)
                    Text(text = "${m?.streakSummary?.currentStreakDays ?: 0}d", style = MaterialTheme.typography.headlineMedium)
                    Text(text = if (isHindi) "वर्तमान स्ट्रीक" else "Active Streak", style = MaterialTheme.typography.bodyMedium)
                }
                FitGoCard(modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = LocalFitGoColors.current.primary)
                    Text(text = "${m?.totalPersonalRecords ?: 0}", style = MaterialTheme.typography.headlineMedium)
                    Text(text = if (isHindi) "कुल PRs" else "Total PRs", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            val m = metrics
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FitGoCard(modifier = Modifier.weight(1f)) {
                    Text(text = "${m?.totalWorkouts ?: 0}", style = MaterialTheme.typography.headlineMedium)
                    Text(text = if (isHindi) "कुल वर्कआउट" else "Workouts Completed", style = MaterialTheme.typography.bodyMedium)
                }
                FitGoCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = UnitConverter.formatVolume(m?.totalVolumeKg ?: 0.0, settings.weightUnit),
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(text = if (isHindi) "कुल वॉल्यूम" else "Lifetime Volume", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            val weekly = metrics?.weeklyVolumeByDay.orEmpty()
            FitGoCard {
                Text(
                    text = if (isHindi) "साप्ताहिक प्रशिक्षण वॉल्यूम" else "Weekly Training Volume (${settings.weightUnit.symbol})",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                if (weekly.all { it.second == 0.0 }) {
                    Text(
                        text = if (isHindi) "चार्ट देखने के लिए अपना पहला वर्कआउट पूरा करें।" else "Complete your first workout to populate weekly volume bars.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LocalFitGoColors.current.onSurfaceVariant
                    )
                } else {
                    FitGoBarChart(dataPoints = weekly, accessibilityTitle = "Weekly training volume chart")
                }
            }
        }

        item {
            Text(text = if (isHindi) "त्वरित रूटीन शुरू करें" else "Quick-Start Routines", style = MaterialTheme.typography.titleLarge)
        }
        items(routines, key = { it.id }) { routine ->
            FitGoCard(
                onClick = {
                    viewModel.startWorkout(title = routine.name, routineId = routine.id)
                    onNavigateToWorkout()
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = routine.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = routine.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = LocalFitGoColors.current.onSurfaceVariant
                        )
                    }
                    AccessibleStatusBadge(label = if (routine.isSampleRoutine) "Sample" else "Custom")
                }
            }
        }
    }
}
