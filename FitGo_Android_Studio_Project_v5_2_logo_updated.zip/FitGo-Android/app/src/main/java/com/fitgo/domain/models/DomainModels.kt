package com.fitgo.domain.models

import com.fitgo.core.utils.OverloadSuggestion
import com.fitgo.core.utils.StreakSummary
import com.fitgo.data.database.entities.ExerciseEntity
import com.fitgo.data.database.entities.PersonalRecordEntity
import com.fitgo.data.database.entities.WorkoutEntity
import com.fitgo.data.database.entities.WorkoutExerciseEntity
import com.fitgo.data.database.entities.WorkoutSetEntity

data class ActiveWorkoutExerciseBlock(
    val workoutExercise: WorkoutExerciseEntity,
    val exercise: ExerciseEntity,
    val sets: List<WorkoutSetEntity>,
    val previousSessionSets: List<WorkoutSetEntity>,
    val overloadSuggestion: OverloadSuggestion?
)

data class CompletedWorkoutSummary(
    val workout: WorkoutEntity,
    val exerciseCount: Int,
    val completedSetsCount: Int,
    val totalVolumeKg: Double,
    val achievedPrs: List<PersonalRecordEntity>,
    val previousVolumeDeltaKg: Double?
)

data class DashboardMetrics(
    val totalWorkouts: Int,
    val totalVolumeKg: Double,
    val totalPersonalRecords: Int,
    val streakSummary: StreakSummary,
    val recentWorkout: WorkoutEntity?,
    val weeklyVolumeByDay: List<Pair<String, Double>>,
    val muscleDistribution: Map<String, Int>
)
