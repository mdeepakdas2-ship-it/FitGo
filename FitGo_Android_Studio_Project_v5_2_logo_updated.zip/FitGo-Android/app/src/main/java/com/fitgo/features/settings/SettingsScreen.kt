package com.fitgo.features.settings

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.fitgo.core.design.AccentPalette
import com.fitgo.core.design.AccessibleStatusBadge
import com.fitgo.core.design.FitGoCard
import com.fitgo.core.design.HexColorValidator
import com.fitgo.core.design.LocalFitGoColors
import com.fitgo.core.design.ThemeMode
import com.fitgo.core.utils.DistanceUnit
import com.fitgo.core.utils.WeightUnit
import com.fitgo.features.FitGoMainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsAndAppearanceScreen(viewModel: FitGoMainViewModel) {
    val settings by viewModel.settingsState.collectAsState()
    val billingStatus by viewModel.playBillingManager.billingStatus.collectAsState()
    val proPrice by viewModel.playBillingManager.localizedPrice.collectAsState()
    val context = LocalContext.current
    var customHexInput by remember(settings.customHexColor) {
        mutableStateOf(settings.customHexColor ?: "#7654E8")
    }
    val scope = rememberCoroutineScope()
    var backupPassword by remember { mutableStateOf("") }
    var restorePassword by remember { mutableStateOf("") }
    var showBackupPasswordDialog by remember { mutableStateOf(false) }
    var showRestorePasswordDialog by remember { mutableStateOf(false) }
    var restoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingBackupBytes by remember { mutableStateOf<ByteArray?>(null) }
    var dataMessage by remember { mutableStateOf<String?>(null) }
    val createBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val bytes = pendingBackupBytes
        if (uri != null && bytes != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: error("Cannot open selected file")
            }.onSuccess { dataMessage = "Encrypted backup saved successfully." }
                .onFailure { dataMessage = "Backup could not be saved: ${it.message}" }
        }
        pendingBackupBytes = null
    }
    val openBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        restoreUri = uri
        showRestorePasswordDialog = uri != null
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val csv = viewModel.exportWorkoutHistoryCsv()
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
                    ?: error("Cannot open selected file")
            }.onSuccess { dataMessage = "Workout history CSV exported." }
                .onFailure { dataMessage = "CSV export failed: ${it.message}" }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Settings & Appearance", style = MaterialTheme.typography.headlineLarge)
        }

        item {
            FitGoCard {
                Text("Theme Mode (Instant Live Preview)", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { viewModel.updateThemeMode(mode) },
                            label = { Text(mode.name) }
                        )
                    }
                }

                if (settings.themeMode == ThemeMode.AUTO_SCHEDULE) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Automatic Day/Night Schedule: Day starts at %02d:%02d • Night starts at %02d:%02d".format(
                            settings.dayStartMinutes / 60, settings.dayStartMinutes % 60,
                            settings.nightStartMinutes / 60, settings.nightStartMinutes % 60
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.updateAutoSchedule(6 * 60, 18 * 60) }) { Text("6 AM / 6 PM") }
                        OutlinedButton(onClick = { viewModel.updateAutoSchedule(7 * 60, 20 * 60) }) { Text("7 AM / 8 PM") }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("Accent Colour Palettes", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccentPalette.entries.forEach { palette ->
                        val isSelected = settings.accentPalette == palette && settings.customHexColor == null
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(palette.primaryColor)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) LocalFitGoColors.current.onBackground else LocalFitGoColors.current.outline,
                                    shape = CircleShape
                                )
                                .clickable { viewModel.updateAccentPalette(palette) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = palette.displayNameEn,
                                    tint = HexColorValidator.accessibleOnColor(palette.primaryColor)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = customHexInput,
                        onValueChange = { customHexInput = it },
                        label = { Text("Custom HEX (#RRGGBB)") },
                        isError = !HexColorValidator.isValidHex(customHexInput),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (HexColorValidator.isValidHex(customHexInput)) {
                                viewModel.updateCustomHexColor(customHexInput)
                            }
                        },
                        enabled = HexColorValidator.isValidHex(customHexInput)
                    ) {
                        Text("Apply HEX")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = { viewModel.resetAppearance() }) {
                    Text("Reset Appearance Settings")
                }
            }
        }

        item {
            FitGoCard {
                Text("Localization & Units", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = settings.languageCode == "en", onClick = { viewModel.updateLanguage("en") }, label = { Text("English") })
                    FilterChip(selected = settings.languageCode == "hi", onClick = { viewModel.updateLanguage("hi") }, label = { Text("हिन्दी (Hindi)") })
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WeightUnit.entries.forEach { u ->
                        FilterChip(
                            selected = settings.weightUnit == u,
                            onClick = { viewModel.updateUnits(u, settings.distanceUnit, settings.lengthUnit) },
                            label = { Text("Weight: ${u.symbol}") }
                        )
                    }
                    DistanceUnit.entries.forEach { d ->
                        FilterChip(
                            selected = settings.distanceUnit == d,
                            onClick = { viewModel.updateUnits(settings.weightUnit, d, settings.lengthUnit) },
                            label = { Text("Dist: ${d.symbol}") }
                        )
                    }
                }
            }
        }

        item {
            FitGoCard {
                Text("Your Data & Backup", style = MaterialTheme.typography.titleLarge)
                Text("Your workouts stay on this device. Create an encrypted backup before changing phones or reinstalling the app.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                if (settings.isProEntitled) {
                    Button(onClick = { showBackupPasswordDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Create Encrypted Backup")
                    }
                    OutlinedButton(onClick = { openBackupLauncher.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Restore From Backup")
                    }
                } else {
                    Text("Encrypted backup and restore are included with Lifetime Pro.", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick = { csvLauncher.launch("FitGo_Workout_History.csv") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Export Workout History CSV")
                }
                dataMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = LocalFitGoColors.current.primary) }
            }
        }

        item {
            FitGoCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("FitGo Pro — Lifetime Unlock", style = MaterialTheme.typography.titleLarge)
                    AccessibleStatusBadge(
                        label = if (settings.isProEntitled) "Pro Active" else billingStatus.name,
                        isSuccess = settings.isProEntitled
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "One-time purchase ($proPrice). Unlocks Custom Routine Builder, Encrypted Backups, Body Measurements, and Custom Themes. No recurring subscription.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { context.findActivity()?.let { viewModel.playBillingManager.launchLifetimeProPurchaseFlow(it) } },
                    enabled = !settings.isProEntitled && billingStatus.name == "READY"
                ) {
                    Text(if (settings.isProEntitled) "Pro Unlocked" else "Unlock Lifetime Pro — $proPrice")
                }
                OutlinedButton(onClick = { viewModel.playBillingManager.restorePurchases() }) {
                    Text("Restore Google Play Purchases")
                }
                Text(
                    "Purchases are verified using the Play Console licensing public key configured by the developer.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalFitGoColors.current.onSurfaceVariant
                )
            }
        }
    }

    if (showBackupPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showBackupPasswordDialog = false },
            title = { Text("Protect your backup") },
            text = {
                Column {
                    Text("Use at least 8 characters. Keep this password safe; it cannot be recovered.")
                    OutlinedTextField(backupPassword, { backupPassword = it }, label = { Text("Backup password") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = backupPassword.length >= 8, onClick = {
                    showBackupPasswordDialog = false
                    scope.launch {
                        val password = backupPassword.toCharArray()
                        try {
                            runCatching { viewModel.exportEncryptedBackup(password) }
                                .onSuccess { bytes -> pendingBackupBytes = bytes; createBackupLauncher.launch("FitGo_Backup.fitgo") }
                                .onFailure { dataMessage = "Backup creation failed: ${it.message}" }
                        } finally {
                            password.fill('\u0000')
                            backupPassword = ""
                        }
                    }
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showBackupPasswordDialog = false }) { Text("Cancel") } }
        )
    }

    if (showRestorePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showRestorePasswordDialog = false; restoreUri = null },
            title = { Text("Restore your backup") },
            text = {
                Column {
                    Text("Enter the password used when this backup was created. Restore replaces the current local data.")
                    OutlinedTextField(restorePassword, { restorePassword = it }, label = { Text("Backup password") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = restorePassword.isNotBlank() && restoreUri != null, onClick = {
                    showRestorePasswordDialog = false
                    val selectedUri = restoreUri
                    scope.launch {
                        runCatching {
                            val bytes = selectedUri?.let { context.contentResolver.openInputStream(it)?.use { stream -> stream.readBytes() } }
                                ?: error("Cannot read selected backup")
                            val password = restorePassword.toCharArray()
                            try { viewModel.restoreEncryptedBackup(bytes, password) }
                            finally { password.fill('\u0000') }
                        }.onSuccess { summary ->
                            runCatching {
                                context.openFileOutput("fitgo_pre_restore_safety.fitgo", android.content.Context.MODE_PRIVATE).use {
                                    it.write(summary.safetySnapshotBytes)
                                }
                            }
                            dataMessage = "Restored ${summary.workoutsRestored} workouts and ${summary.exercisesRestored} exercises. A safety snapshot was stored inside FitGo."
                        }.onFailure { dataMessage = "Restore failed. Current data was not replaced: ${it.message}" }
                        restorePassword = ""
                        restoreUri = null
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showRestorePasswordDialog = false; restoreUri = null }) { Text("Cancel") } }
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
