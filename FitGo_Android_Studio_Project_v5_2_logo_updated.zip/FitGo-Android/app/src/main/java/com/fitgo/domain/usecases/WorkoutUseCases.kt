package com.fitgo.domain.usecases

import com.fitgo.data.database.entities.WorkoutSetEntity
import com.fitgo.data.repositories.FitGoRepository
import com.fitgo.domain.models.CompletedWorkoutSummary
import javax.inject.Inject

class StartOrResumeWorkoutUseCase @Inject constructor(
    private val repository: FitGoRepository
) {
    suspend operator fun invoke(title: String, routineId: String? = null) =
        repository.startNewWorkout(title, routineId)
}

class LogWorkoutSetUseCase @Inject constructor(
    private val repository: FitGoRepository
) {
    suspend operator fun invoke(set: WorkoutSetEntity) =
        repository.saveOrUpdateSet(set)
}

class FinishWorkoutUseCase @Inject constructor(
    private val repository: FitGoRepository
) {
    suspend operator fun invoke(workoutId: String, notes: String): CompletedWorkoutSummary =
        repository.finishWorkoutSession(workoutId, notes)
}
