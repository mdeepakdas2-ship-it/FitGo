package com.fitgo

import com.fitgo.core.design.AutoThemeEvaluator
import com.fitgo.core.design.HexColorValidator
import com.fitgo.core.security.CryptoManager
import com.fitgo.core.utils.DistanceUnit
import com.fitgo.core.utils.HistoricalSessionSnapshot
import com.fitgo.core.utils.LengthUnit
import com.fitgo.core.utils.OverloadAction
import com.fitgo.core.utils.PlateCalculator
import com.fitgo.core.utils.PrCalculator
import com.fitgo.core.utils.ProgressiveOverloadEngine
import com.fitgo.core.utils.RestTimerState
import com.fitgo.core.utils.StreakCalculator
import com.fitgo.core.utils.UnitConverter
import com.fitgo.core.utils.WeightUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class FitGoUnitTestSuite {

    @Test
    fun unitConverter_preservesUnderlyingValuesRoundTrip() {
        val originalKg = 100.0
        val lbs = UnitConverter.kgToDisplay(originalKg, WeightUnit.LBS)
        assertEquals(220.46226, lbs, 0.001)
        assertEquals(originalKg, UnitConverter.displayToKg(lbs, WeightUnit.LBS), 1e-6)
        assertEquals(5.0, UnitConverter.displayToKm(UnitConverter.kmToDisplay(5.0, DistanceUnit.MI), DistanceUnit.MI), 1e-6)
        assertEquals(40.0, UnitConverter.displayToCm(UnitConverter.cmToDisplay(40.0, LengthUnit.IN), LengthUnit.IN), 1e-6)
    }

    @Test
    fun prCalculator_epleyFormulaAccurateAndRejectsInvalidRanges() {
        assertEquals(120.0, PrCalculator.calculateEstimated1RmKg(100.0, 6, true)!!, 0.001)
        assertEquals(140.0, PrCalculator.calculateEstimated1RmKg(140.0, 1, true)!!, 0.001)
        assertNull(PrCalculator.calculateEstimated1RmKg(60.0, 20, true))
        assertNull(PrCalculator.calculateEstimated1RmKg(60.0, 8, false))
    }

    @Test
    fun progressiveOverloadEngine_recommendsWeightJumpOrRepIncrease() {
        val readyToJump = listOf(HistoricalSessionSnapshot(1000L, 80.0, 10, 3, 2400.0))
        val suggestion = ProgressiveOverloadEngine.analyze("ex_bench_press", readyToJump)
        assertNotNull(suggestion)
        assertEquals(OverloadAction.INCREASE_WEIGHT, suggestion!!.action)
        assertEquals(82.5, suggestion.suggestedWeightKg!!, 0.01)
    }

    @Test
    fun restTimer_timestampCalculationRemainsAccurateAcrossBackgroundDelays() {
        val t0 = 1_000_000L
        val timer = RestTimerState.start(durationSeconds = 90, nowEpochMillis = t0)
        assertEquals(45, timer.remainingSeconds(t0 + 45_000L))
        val adjusted = RestTimerState.adjustSeconds(timer, +15, nowEpochMillis = t0 + 45_000L)
        assertEquals(60, adjusted.remainingSeconds(t0 + 45_000L))
    }

    @Test
    fun aes256GcmBackupEncryption_roundTripAndTamperDetection() {
        val sampleJson = "{\"schemaVersion\":5,\"workouts\":[]}"
        val password = "CorrectHorseBatteryStaple!99".toCharArray()
        val encrypted = CryptoManager.encryptBackupPayload(sampleJson, password)
        val decrypted = CryptoManager.decryptBackupPayload(encrypted, password)
        assertEquals(sampleJson, decrypted)
        val wrongPasswordRejected = runCatching {
            CryptoManager.decryptBackupPayload(encrypted, "WrongPassword!".toCharArray())
        }.isFailure
        assertTrue(wrongPasswordRejected)
    }

    @Test
    fun autoThemeSchedule_evaluatesDayAndNightWindowsCorrectly() {
        assertFalse(AutoThemeEvaluator.isNightTimeNow(LocalTime.of(10, 30), 360, 1080))
        assertTrue(AutoThemeEvaluator.isNightTimeNow(LocalTime.of(21, 15), 360, 1080))
    }

    @Test
    fun hexColorValidator_validatesAndNormalizesHexStrings() {
        assertTrue(HexColorValidator.isValidHex("#7654E8"))
        assertFalse(HexColorValidator.isValidHex("#GGGGGG"))
        assertEquals("#159B72", HexColorValidator.normalizeHex("159b72"))
    }

    @Test
    fun plateCalculator_computesExactSymmetricLoading() {
        val res = PlateCalculator.calculatePerSide(targetWeight = 100.0, barWeight = 20.0)
        assertTrue(res.isValid)
        assertEquals(100.0, res.achievableWeight, 0.001)
        assertEquals(listOf(25.0 to 1, 15.0 to 1), res.perSidePlates)
    }

    @Test
    fun plateCalculator_rejectsTargetBelowBarAndNonFiniteInputs() {
        val belowBar = PlateCalculator.calculatePerSide(targetWeight = 10.0, barWeight = 20.0)
        assertFalse(belowBar.isValid)
        assertNotNull(belowBar.errorMessage)
        val notANumber = PlateCalculator.calculatePerSide(targetWeight = Double.NaN, barWeight = 20.0)
        assertFalse(notANumber.isValid)
    }

    @Test
    fun streakCalculator_allowsConfiguredRestDaysWithoutBreakingStreak() {
        val today = LocalDate.of(2026, 11, 3)
        val dates = setOf(today.minusDays(6), today.minusDays(4), today.minusDays(1), today)
        val summary = StreakCalculator.calculateStreaks(dates, today, maxRestDaysBetweenWorkouts = 2)
        assertEquals(4, summary.currentStreakDays)
    }
}
