-keepattributes *Annotation*,InnerClasses,Signature,EnclosingMethod
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
-keep class com.fitgo.data.backup.** { *; }
-keep class com.fitgo.data.database.entities.** { *; }
-dontwarn javax.crypto.**
