# Build FitGo in Android Studio

1. Extract the complete `FitGo-Android` folder.
2. Open Android Studio → **Open** → select the `FitGo-Android` folder.
3. Install Android SDK Platform 35 and Android SDK Build-Tools 35.x from SDK Manager.
4. Use JDK 17 (Android Studio's embedded JBR is suitable if configured as Gradle JDK).
5. Allow Gradle sync to finish. If prompted, install the Android Gradle Plugin / Kotlin plugin versions declared in `gradle/libs.versions.toml`.
6. Run the `app` configuration on an Android 8.0+ device/emulator.
7. For a debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. For a Play release: **Build → Generate Signed Bundle / APK → Android App Bundle**, then sign with your own protected upload key.

## Google Play Billing setup

Set `FITGO_PLAY_PUBLIC_KEY` in the user's Gradle properties file (`~/.gradle/gradle.properties`) to the Base64 licensing public key from Play Console. Do not put private credentials or an upload keystore in source control. Create the product `fitgo_pro_lifetime` and test it using a Play internal-testing track.

## Important

The source archive intentionally does not include signing keys, Play credentials, or an APK. The original supplied archive also lacked Gradle wrapper files. Open the project in Android Studio so it can resolve Gradle; do not claim a successful build until Android Studio reports a successful build and the app has been tested on a device.
